<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher', 'Director of Studies']);

$pdo = get_db_connection();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';
    $email     = trim($_POST['email'] ?? '');
    $phone     = trim($_POST['phone'] ?? '');
    $division  = $_POST['division'] ?? 'All';

    if (empty($full_name) || empty($username) || empty($password)) {
        $errors[] = "Full name, username, and password are required.";
    }

    if (empty($errors)) {
        // Check duplicate username
        $chk = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $chk->execute([$username]);
        if ($chk->fetch()) {
            $errors[] = "Username '{$username}' is already taken.";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, full_name, email, phone, role, assigned_division, status) VALUES (?, ?, ?, ?, ?, 'Teacher', ?, 'Active')");
            $stmt->execute([$username, $hash, $full_name, $email, $phone, $division]);

            log_audit('Teacher Registered', "Added teacher account {$username} ({$full_name})");
            set_flash('success', "Teacher {$full_name} registered successfully!");
            redirect('teachers/index.php');
        }
    }
}

$page_title = 'Register New Teacher';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Add Teacher Account</h3>
                <p class="text-muted mb-0">Create login and teaching profile</p>
            </div>
            <a href="<?= BASE_URL ?>teachers/index.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Back
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger shadow-sm">
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $e): ?>
                        <li><?= e($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="full_name" class="form-control" placeholder="e.g. Mr. James Kariuki" value="<?= e($_POST['full_name'] ?? '') ?>" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Username <span class="text-danger">*</span></label>
                            <input type="text" name="username" class="form-control" placeholder="e.g. james_k" value="<?= e($_POST['username'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="07XXXXXXXX" value="<?= e($_POST['phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="teacher@kombeschools.sc.ke" value="<?= e($_POST['email'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Assigned School Division</label>
                        <select name="division" class="form-select">
                            <option value="All">All Divisions (Primary & Junior)</option>
                            <option value="Primary">Kombe AIC Primary School Only</option>
                            <option value="Junior">Kombe AIC Junior School Only</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-end gap-2 border-top pt-3">
                        <a href="<?= BASE_URL ?>teachers/index.php" class="btn btn-light border">Cancel</a>
                        <button type="submit" class="btn btn-primary fw-semibold">
                            <i class="bi bi-person-check-fill me-1"></i> Register Teacher
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
