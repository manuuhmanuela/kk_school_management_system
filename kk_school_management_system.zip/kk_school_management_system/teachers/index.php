<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher', 'Director of Studies']);

$page_title = 'Teachers & Subject Allocation';
$pdo = get_db_connection();

// Fetch all teachers
$teachers_stmt = $pdo->query("SELECT * FROM users WHERE role = 'Teacher' ORDER BY full_name ASC");
$teachers = $teachers_stmt->fetchAll();

// Fetch teacher allocations
$alloc_stmt = $pdo->query("
    SELECT ta.*, u.full_name as teacher_name, c.name as class_name, c.division, c.stream, s.subject_name, s.subject_code 
    FROM teacher_allocations ta 
    JOIN users u ON ta.teacher_id = u.id 
    JOIN classes c ON ta.class_id = c.id 
    JOIN subjects s ON ta.subject_id = s.id 
    ORDER BY c.division ASC, c.id ASC, s.subject_name ASC
");
$allocations = $alloc_stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Teacher Management & Subject Allocation</h3>
        <p class="text-muted mb-0">Manage teaching staff and assign subject responsibilities across Primary and Junior divisions</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>teachers/allocate.php" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-diagram-3 me-1"></i> Allocate Subject
        </a>
        <a href="<?= BASE_URL ?>teachers/create.php" class="btn btn-primary btn-sm shadow-sm">
            <i class="bi bi-person-plus-fill me-1"></i> Add New Teacher
        </a>
    </div>
</div>

<div class="row g-4">
    <!-- Registered Teachers Column -->
    <div class="col-lg-5">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold"><i class="bi bi-person-badge me-2 text-primary"></i>Teaching Faculty (<?= count($teachers) ?>)</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Name & Username</th>
                                <th>Assigned Division</th>
                                <th>Contact</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($teachers as $t): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= e($t['full_name']) ?></div>
                                        <small class="text-muted">Username: <code><?= e($t['username']) ?></code></small>
                                    </td>
                                    <td>
                                        <span class="badge <?= ($t['assigned_division'] === 'Primary') ? 'bg-primary' : (($t['assigned_division'] === 'Junior') ? 'bg-warning text-dark' : 'bg-secondary') ?>">
                                            <?= e($t['assigned_division']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="small"><?= e($t['phone'] ?? 'N/A') ?></div>
                                        <small class="text-muted"><?= e($t['email'] ?? '') ?></small>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Active Allocations Column -->
    <div class="col-lg-7">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold"><i class="bi bi-journal-bookmark me-2 text-success"></i>Current Subject & Class Allocations</h6>
                <a href="<?= BASE_URL ?>teachers/allocate.php" class="btn btn-sm btn-link text-decoration-none">Manage</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Division / Grade</th>
                                <th>Subject</th>
                                <th>Teacher Responsible</th>
                                <th>Academic Year</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($allocations)): ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">No subject allocations made yet. Click 'Allocate Subject' to assign.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($allocations as $a): ?>
                                    <tr>
                                        <td>
                                            <span class="badge <?= ($a['division'] === 'Primary') ? 'bg-primary-subtle text-primary' : 'bg-warning-subtle text-warning-emphasis' ?>">
                                                <?= e($a['division']) ?>
                                            </span>
                                            <strong><?= e($a['class_name']) ?></strong> (<?= e($a['stream']) ?>)
                                        </td>
                                        <td>
                                            <div class="fw-semibold"><?= e($a['subject_name']) ?></div>
                                            <small class="text-muted"><?= e($a['subject_code']) ?></small>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= e($a['teacher_name']) ?></div>
                                        </td>
                                        <td><?= e($a['academic_year']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
