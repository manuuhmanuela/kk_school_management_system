<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher', 'Director of Studies']);

$pdo = get_db_connection();
$errors = [];

// Handle allocation deletion
if (isset($_GET['delete'])) {
    $del_id = intval($_GET['delete']);
    $pdo->prepare("DELETE FROM teacher_allocations WHERE id = ?")->execute([$del_id]);
    set_flash('success', 'Teacher allocation removed successfully.');
    redirect('teachers/allocate.php');
}

// Handle new allocation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher_id = intval($_POST['teacher_id'] ?? 0);
    $class_id   = intval($_POST['class_id'] ?? 0);
    $subject_id = intval($_POST['subject_id'] ?? 0);
    $year       = trim($_POST['academic_year'] ?? date('Y'));

    if (!$teacher_id || !$class_id || !$subject_id) {
        $errors[] = "Please select teacher, class, and subject.";
    }

    if (empty($errors)) {
        // Check if subject is already assigned for that class and year
        $chk = $pdo->prepare("SELECT id FROM teacher_allocations WHERE class_id = ? AND subject_id = ? AND academic_year = ?");
        $chk->execute([$class_id, $subject_id, $year]);
        if ($chk->fetch()) {
            $errors[] = "This subject is already allocated to a teacher in this class for the year {$year}.";
        } else {
            $ins = $pdo->prepare("INSERT INTO teacher_allocations (teacher_id, class_id, subject_id, academic_year) VALUES (?, ?, ?, ?)");
            $ins->execute([$teacher_id, $class_id, $subject_id, $year]);
            
            log_audit('Subject Allocated', "Allocated subject ID {$subject_id} to teacher ID {$teacher_id} for class ID {$class_id}");
            set_flash('success', 'Subject allocation successfully created!');
            redirect('teachers/allocate.php');
        }
    }
}

// Fetch form options
$teachers = $pdo->query("SELECT id, full_name, assigned_division FROM users WHERE role = 'Teacher' ORDER BY full_name ASC")->fetchAll();
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();
$subjects = $pdo->query("SELECT id, subject_code, subject_name, division FROM subjects ORDER BY division ASC, subject_name ASC")->fetchAll();

// Existing allocations
$allocations = $pdo->query("
    SELECT ta.*, u.full_name as teacher_name, c.name as class_name, c.division, c.stream, s.subject_name 
    FROM teacher_allocations ta 
    JOIN users u ON ta.teacher_id = u.id 
    JOIN classes c ON ta.class_id = c.id 
    JOIN subjects s ON ta.subject_id = s.id 
    ORDER BY ta.id DESC
")->fetchAll();

$page_title = 'Allocate Subjects to Teachers';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Subject & Class Allocation</h3>
        <p class="text-muted mb-0">Assign teachers to their respective subject disciplines and grades</p>
    </div>
    <a href="<?= BASE_URL ?>teachers/index.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back to Faculty
    </a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger shadow-sm">
        <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e): ?>
                <li><?= e($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Allocation Form -->
    <div class="col-lg-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold">
                <i class="bi bi-plus-circle me-1 text-primary"></i> Assign Teaching Duty
            </div>
            <div class="card-body p-3">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Teacher</label>
                        <select name="teacher_id" class="form-select" required>
                            <option value="">-- Choose Teacher --</option>
                            <?php foreach ($teachers as $t): ?>
                                <option value="<?= $t['id'] ?>"><?= e($t['full_name']) ?> (<?= e($t['assigned_division']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Class / Grade</label>
                        <select name="class_id" class="form-select" required>
                            <option value="">-- Choose Class --</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['id'] ?>">[<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Subject</label>
                        <select name="subject_id" class="form-select" required>
                            <option value="">-- Choose Subject --</option>
                            <?php foreach ($subjects as $s): ?>
                                <option value="<?= $s['id'] ?>">[<?= e($s['division']) ?>] <?= e($s['subject_name']) ?> (<?= e($s['subject_code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Academic Year</label>
                        <input type="text" name="academic_year" class="form-control" value="2026" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary fw-semibold">
                            <i class="bi bi-save me-1"></i> Save Allocation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Current Allocations List -->
    <div class="col-lg-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold">
                <i class="bi bi-list-check me-1 text-primary"></i> Active Allocation Roster (<?= count($allocations) ?>)
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Teacher</th>
                                <th>Class & Division</th>
                                <th>Subject</th>
                                <th>Year</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($allocations)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">No allocations saved yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($allocations as $row): ?>
                                    <tr>
                                        <td class="fw-bold text-dark"><?= e($row['teacher_name']) ?></td>
                                        <td>
                                            <span class="badge <?= ($row['division'] === 'Primary') ? 'bg-primary-subtle text-primary' : 'bg-warning-subtle text-warning-emphasis' ?>">
                                                <?= e($row['division']) ?>
                                            </span>
                                            <?= e($row['class_name']) ?>
                                        </td>
                                        <td><?= e($row['subject_name']) ?></td>
                                        <td><?= e($row['academic_year']) ?></td>
                                        <td class="text-end">
                                            <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('Remove this subject allocation?');" title="Remove">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
