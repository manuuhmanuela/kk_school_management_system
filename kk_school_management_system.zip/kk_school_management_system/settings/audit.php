<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator']);

$pdo = get_db_connection();

// Fetch recent audit events
$stmt = $pdo->query("
    SELECT a.*, u.username, u.full_name, u.role 
    FROM audit_logs a 
    LEFT JOIN users u ON a.user_id = u.id 
    ORDER BY a.id DESC LIMIT 100
");
$logs = $stmt->fetchAll();

$page_title = 'System Audit Logs';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">System Security & Audit Trail</h3>
        <p class="text-muted mb-0">Traceability of all user logins, student modifications, marks entries and financial actions</p>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 fw-bold d-flex justify-content-between align-items-center">
        <span><i class="bi bi-shield-check me-2 text-primary"></i>Activity Audit Trail (Last <?= count($logs) ?> Events)</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 font-monospace small">
                <thead class="table-light">
                    <tr>
                        <th style="width: 170px;">Timestamp</th>
                        <th>User Account</th>
                        <th>Role</th>
                        <th>Action Performed</th>
                        <th>Details / Entity</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">No audit events recorded.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($logs as $l): ?>
                            <tr>
                                <td class="text-secondary"><?= e($l['created_at']) ?></td>
                                <td class="fw-bold text-dark"><?= e($l['full_name'] ?? 'System') ?> (<?= e($l['username'] ?? 'sys') ?>)</td>
                                <td><span class="badge bg-light text-dark border"><?= e($l['role'] ?? 'System') ?></span></td>
                                <td><strong class="text-primary"><?= e($l['action']) ?></strong></td>
                                <td class="font-sans-serif"><?= e($l['details']) ?></td>
                                <td class="text-muted"><?= e($l['ip_address']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
