<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$errors = [];

// Handle Form Submission BEFORE any HTML output
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admission_no   = trim($_POST['admission_no'] ?? '');
    $first_name     = trim($_POST['first_name'] ?? '');
    $middle_name    = trim($_POST['middle_name'] ?? '');
    $last_name      = trim($_POST['last_name'] ?? '');
    $gender         = $_POST['gender'] ?? '';
    $dob            = !empty($_POST['dob']) ? $_POST['dob'] : null;
    $class_id       = intval($_POST['class_id'] ?? 0);
    $parent_name    = trim($_POST['parent_name'] ?? '');
    $parent_phone   = trim($_POST['parent_phone'] ?? '');
    $parent_email   = trim($_POST['parent_email'] ?? '');
    $address        = trim($_POST['address'] ?? '');
    $admission_date = !empty($_POST['admission_date']) ? $_POST['admission_date'] : date('Y-m-d');

    // Validation
    if (empty($admission_no)) $errors[] = "Admission number is required.";
    if (empty($first_name)) $errors[] = "First name is required.";
    if (empty($last_name)) $errors[] = "Last name is required.";
    if (empty($gender)) $errors[] = "Gender selection is required.";
    if ($class_id <= 0) $errors[] = "Please select a valid class.";

    // Get Class division
    $class_stmt = $pdo->prepare("SELECT division FROM classes WHERE id = ?");
    $class_stmt->execute([$class_id]);
    $class_row = $class_stmt->fetch();
    if (!$class_row) {
        $errors[] = "Selected class does not exist.";
    } else {
        $division = $class_row['division'];
    }

    // Check duplicate admission number
    if (empty($errors)) {
        $dup_stmt = $pdo->prepare("SELECT id FROM students WHERE admission_no = ?");
        $dup_stmt->execute([$admission_no]);
        if ($dup_stmt->fetch()) {
            $errors[] = "A student with admission number '{$admission_no}' is already registered.";
        }
    }

    // Insert student
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO students 
            (admission_no, first_name, middle_name, last_name, gender, date_of_birth, current_class_id, division, parent_name, parent_phone, parent_email, residential_address, status, admission_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?)");
        
        $stmt->execute([
            $admission_no, $first_name, $middle_name, $last_name, $gender, 
            $dob, $class_id, $division, $parent_name, $parent_phone, 
            $parent_email, $address, $admission_date
        ]);

        $new_student_id = $pdo->lastInsertId();
        log_audit('Student Registered', "Added student {$admission_no} ({$first_name} {$last_name}) to Class ID {$class_id}");
        set_flash('success', "Learner {$first_name} {$last_name} ({$admission_no}) has been successfully enrolled!");
        
        // Clean redirect - zero headers sent issues
        redirect('students/view.php?id=' . $new_student_id);
    }
}

// Fetch classes for dropdown
$classes = $pdo->query("SELECT * FROM classes ORDER BY division ASC, id ASC")->fetchAll();

$page_title = 'Register New Student';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">New Student Registration</h3>
                <p class="text-muted mb-0">Enroll learner into Kombe AIC Primary or Junior School</p>
            </div>
            <a href="<?= BASE_URL ?>students/index.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Back to Students
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger shadow-sm">
                <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-octagon-fill me-1"></i> Please fix the following errors:</h6>
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $err): ?>
                        <li><?= e($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form method="POST" action="">
                    <h5 class="fw-bold text-primary mb-3"><i class="bi bi-person-lines-fill me-2"></i>1. Student Biodata</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Admission Number <span class="text-danger">*</span></label>
                            <input type="text" name="admission_no" class="form-control" placeholder="e.g. KK/PRI/2026/010" value="<?= e($_POST['admission_no'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Admission Date</label>
                            <input type="date" name="admission_date" class="form-control" value="<?= e($_POST['admission_date'] ?? date('Y-m-d')) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Class & Division <span class="text-danger">*</span></label>
                            <select name="class_id" class="form-select" required>
                                <option value="">-- Choose Class --</option>
                                <optgroup label="KOMBE AIC PRIMARY SCHOOL (Grades 4–6)">
                                    <?php foreach ($classes as $c): if ($c['division'] === 'Primary'): ?>
                                        <option value="<?= $c['id'] ?>" <?= (($_POST['class_id'] ?? '') == $c['id']) ? 'selected' : '' ?>>
                                            <?= e($c['name']) ?> (Stream: <?= e($c['stream']) ?>)
                                        </option>
                                    <?php endif; endforeach; ?>
                                </optgroup>
                                <optgroup label="KOMBE AIC JUNIOR SCHOOL (Grades 7–9)">
                                    <?php foreach ($classes as $c): if ($c['division'] === 'Junior'): ?>
                                        <option value="<?= $c['id'] ?>" <?= (($_POST['class_id'] ?? '') == $c['id']) ? 'selected' : '' ?>>
                                            <?= e($c['name']) ?> (Stream: <?= e($c['stream']) ?>)
                                        </option>
                                    <?php endif; endforeach; ?>
                                </optgroup>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">First Name <span class="text-danger">*</span></label>
                            <input type="text" name="first_name" class="form-control" placeholder="First Name" value="<?= e($_POST['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Middle Name</label>
                            <input type="text" name="middle_name" class="form-control" placeholder="Middle Name" value="<?= e($_POST['middle_name'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Last Name / Surname <span class="text-danger">*</span></label>
                            <input type="text" name="last_name" class="form-control" placeholder="Last Name" value="<?= e($_POST['last_name'] ?? '') ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Gender <span class="text-danger">*</span></label>
                            <select name="gender" class="form-select" required>
                                <option value="">-- Select Gender --</option>
                                <option value="Male" <?= (($_POST['gender'] ?? '') === 'Male') ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= (($_POST['gender'] ?? '') === 'Female') ? 'selected' : '' ?>>Female</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= e($_POST['dob'] ?? '') ?>">
                        </div>
                    </div>

                    <h5 class="fw-bold text-primary mb-3"><i class="bi bi-telephone-inbound me-2"></i>2. Parent / Guardian Contact Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Parent / Guardian Name</label>
                            <input type="text" name="parent_name" class="form-control" placeholder="Full Name" value="<?= e($_POST['parent_name'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Phone Number</label>
                            <input type="text" name="parent_phone" class="form-control" placeholder="07XXXXXXXX" value="<?= e($_POST['parent_phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Email Address</label>
                            <input type="email" name="parent_email" class="form-control" placeholder="parent@email.com" value="<?= e($_POST['parent_email'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small">Residential / Home Address</label>
                            <textarea name="address" class="form-control" rows="2" placeholder="e.g. Kombe Village, Sub-county, Location"><?= e($_POST['address'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="<?= BASE_URL ?>students/index.php" class="btn btn-light border px-4">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4 fw-semibold">
                            <i class="bi bi-save me-1"></i> Complete Registration
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
