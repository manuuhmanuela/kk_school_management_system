<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$page_title = 'Students Directory';
$pdo = get_db_connection();
$division = get_active_division();

// Filtering parameters
$filter_division = $_GET['division_filter'] ?? (($division !== 'All') ? $division : '');
$filter_class = $_GET['class_id'] ?? '';
$search = trim($_GET['search'] ?? '');
$filter_status = $_GET['status'] ?? 'Active';

// Fetch classes for dropdown
$classes_query = "SELECT * FROM classes WHERE 1=1";
if ($filter_division) {
    $classes_query .= " AND division = " . $pdo->quote($filter_division);
}
$classes_query .= " ORDER BY id ASC";
$classes = $pdo->query($classes_query)->fetchAll();

// Build Students Query
$query = "SELECT s.*, c.name as class_name, c.stream FROM students s JOIN classes c ON s.current_class_id = c.id WHERE 1=1";
$params = [];

if ($filter_division) {
    $query .= " AND s.division = ?";
    $params[] = $filter_division;
}
if ($filter_class) {
    $query .= " AND s.current_class_id = ?";
    $params[] = $filter_class;
}
if ($filter_status) {
    $query .= " AND s.status = ?";
    $params[] = $filter_status;
}
if ($search) {
    $query .= " AND (s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.parent_name LIKE ?)";
    $term = "%$search%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$query .= " ORDER BY s.division ASC, c.id ASC, s.first_name ASC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Include header (guaranteed no headers sent conflict)
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Student Management</h3>
        <p class="text-muted mb-0">Records for Kombe AIC Primary & Kombe AIC Junior Schools</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>progression/index.php" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left-right me-1"></i> Promotion & Transfer
        </a>
        <a href="<?= BASE_URL ?>students/create.php" class="btn btn-primary btn-sm shadow-sm">
            <i class="bi bi-person-plus-fill me-1"></i> Register New Learner
        </a>
    </div>
</div>

<!-- Search & Filter Card -->
<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small fw-semibold text-secondary">Search</label>
                <div class="input-group input-group-sm">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Admission no, Name..." value="<?= e($search) ?>">
                </div>
            </div>
            
            <div class="col-md-2">
                <label class="form-label small fw-semibold text-secondary">Division</label>
                <select name="division_filter" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Divisions</option>
                    <option value="Primary" <?= ($filter_division === 'Primary') ? 'selected' : '' ?>>Primary (Grades 4-6)</option>
                    <option value="Junior" <?= ($filter_division === 'Junior') ? 'selected' : '' ?>>Junior (Grades 7-9)</option>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label small fw-semibold text-secondary">Class / Grade</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Grades</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($filter_class == $c['id']) ? 'selected' : '' ?>>
                            [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label small fw-semibold text-secondary">Status</label>
                <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="Active" <?= ($filter_status === 'Active') ? 'selected' : '' ?>>Active</option>
                    <option value="Promoted" <?= ($filter_status === 'Promoted') ? 'selected' : '' ?>>Promoted</option>
                    <option value="Transferred" <?= ($filter_status === 'Transferred') ? 'selected' : '' ?>>Transferred</option>
                    <option value="Graduated" <?= ($filter_status === 'Graduated') ? 'selected' : '' ?>>Graduated</option>
                    <option value="Alumni" <?= ($filter_status === 'Alumni') ? 'selected' : '' ?>>Alumni</option>
                </select>
            </div>

            <div class="col-md-2 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
                <a href="<?= BASE_URL ?>students/index.php" class="btn btn-outline-secondary btn-sm" title="Clear Filters">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Students Listing Table -->
<div class="card shadow-sm">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold"><i class="bi bi-mortarboard me-2 text-primary"></i>Enrolled Learners List (<?= count($students) ?> found)</h6>
        <button onclick="window.print()" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-printer me-1"></i> Print Roster
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Adm No</th>
                        <th>Student Name</th>
                        <th>Gender</th>
                        <th>Division</th>
                        <th>Grade / Stream</th>
                        <th>Parent / Contact</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <i class="bi bi-folder-x fs-1 d-block mb-2"></i>
                                No student records matched your filter criteria.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($students as $st): ?>
                            <tr>
                                <td class="fw-bold text-primary"><?= e($st['admission_no']) ?></td>
                                <td>
                                    <div class="fw-semibold text-dark"><?= e($st['first_name'] . ' ' . $st['middle_name'] . ' ' . $st['last_name']) ?></div>
                                    <small class="text-muted">Adm: <?= e($st['admission_date'] ?? 'N/A') ?></small>
                                </td>
                                <td><?= e($st['gender']) ?></td>
                                <td>
                                    <span class="badge <?= ($st['division'] === 'Primary') ? 'bg-primary-subtle text-primary border border-primary' : 'bg-warning-subtle text-warning-emphasis border border-warning' ?>">
                                        <?= e($st['division']) ?> School
                                    </span>
                                </td>
                                <td>
                                    <strong><?= e($st['class_name']) ?></strong> 
                                    <small class="text-secondary">(<?= e($st['stream']) ?>)</small>
                                </td>
                                <td>
                                    <div class="small fw-semibold"><?= e($st['parent_name'] ?? 'N/A') ?></div>
                                    <small class="text-muted"><?= e($st['parent_phone'] ?? 'N/A') ?></small>
                                </td>
                                <td>
                                    <?php 
                                    $badge = 'bg-success';
                                    if ($st['status'] === 'Transferred') $badge = 'bg-secondary';
                                    if ($st['status'] === 'Graduated') $badge = 'bg-info text-dark';
                                    if ($st['status'] === 'Alumni') $badge = 'bg-dark';
                                    ?>
                                    <span class="badge <?= $badge ?>"><?= e($st['status']) ?></span>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?= BASE_URL ?>students/view.php?id=<?= $st['id'] ?>" class="btn btn-outline-primary" title="View Profile">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="<?= BASE_URL ?>students/edit.php?id=<?= $st['id'] ?>" class="btn btn-outline-secondary" title="Edit Record">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="<?= BASE_URL ?>reports/print_card.php?student_id=<?= $st['id'] ?>" target="_blank" class="btn btn-outline-info" title="Report Card">
                                            <i class="bi bi-card-checklist"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
