<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$id = intval($_GET['id'] ?? 0);
$pdo = get_db_connection();

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    set_flash('danger', 'Student not found.');
    redirect('students/index.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name     = trim($_POST['first_name'] ?? '');
    $middle_name    = trim($_POST['middle_name'] ?? '');
    $last_name      = trim($_POST['last_name'] ?? '');
    $gender         = $_POST['gender'] ?? '';
    $dob            = !empty($_POST['dob']) ? $_POST['dob'] : null;
    $class_id       = intval($_POST['class_id'] ?? 0);
    $parent_name    = trim($_POST['parent_name'] ?? '');
    $parent_phone   = trim($_POST['parent_phone'] ?? '');
    $parent_email   = trim($_POST['parent_email'] ?? '');
    $address        = trim($_POST['address'] ?? '');
    $status         = $_POST['status'] ?? 'Active';

    if (empty($first_name) || empty($last_name)) {
        $errors[] = "First name and last name are required.";
    }

    $class_stmt = $pdo->prepare("SELECT division FROM classes WHERE id = ?");
    $class_stmt->execute([$class_id]);
    $class_row = $class_stmt->fetch();
    if (!$class_row) {
        $errors[] = "Selected class is invalid.";
    } else {
        $division = $class_row['division'];
    }

    if (empty($errors)) {
        $update = $pdo->prepare("UPDATE students SET 
            first_name = ?, middle_name = ?, last_name = ?, gender = ?, 
            date_of_birth = ?, current_class_id = ?, division = ?, 
            parent_name = ?, parent_phone = ?, parent_email = ?, 
            residential_address = ?, status = ? 
            WHERE id = ?");
        
        $update->execute([
            $first_name, $middle_name, $last_name, $gender, 
            $dob, $class_id, $division, 
            $parent_name, $parent_phone, $parent_email, 
            $address, $status, $id
        ]);

        log_audit('Student Updated', "Updated details for student ID {$id} ({$first_name} {$last_name})");
        set_flash('success', "Student record updated successfully.");
        redirect("students/view.php?id={$id}");
    }
}

$classes = $pdo->query("SELECT * FROM classes ORDER BY division ASC, id ASC")->fetchAll();
$page_title = 'Edit Student: ' . $student['admission_no'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Edit Student Record</h3>
                <p class="text-muted mb-0">Admission No: <strong class="text-primary"><?= e($student['admission_no']) ?></strong></p>
            </div>
            <a href="<?= BASE_URL ?>students/view.php?id=<?= $student['id'] ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Cancel & View Profile
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger shadow-sm">
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $e): ?>
                        <li><?= e($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form method="POST" action="">
                    <h5 class="fw-bold text-primary mb-3">1. Student Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Admission Number (Immutable)</label>
                            <input type="text" class="form-control bg-light" value="<?= e($student['admission_no']) ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Class & Division</label>
                            <select name="class_id" class="form-select" required>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>" <?= ($student['current_class_id'] == $c['id']) ? 'selected' : '' ?>>
                                        [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Enrollment Status</label>
                            <select name="status" class="form-select">
                                <option value="Active" <?= ($student['status'] === 'Active') ? 'selected' : '' ?>>Active</option>
                                <option value="Promoted" <?= ($student['status'] === 'Promoted') ? 'selected' : '' ?>>Promoted</option>
                                <option value="Transferred" <?= ($student['status'] === 'Transferred') ? 'selected' : '' ?>>Transferred</option>
                                <option value="Graduated" <?= ($student['status'] === 'Graduated') ? 'selected' : '' ?>>Graduated</option>
                                <option value="Alumni" <?= ($student['status'] === 'Alumni') ? 'selected' : '' ?>>Alumni</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">First Name</label>
                            <input type="text" name="first_name" class="form-control" value="<?= e($student['first_name']) ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Middle Name</label>
                            <input type="text" name="middle_name" class="form-control" value="<?= e($student['middle_name']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?= e($student['last_name']) ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Gender</label>
                            <select name="gender" class="form-select" required>
                                <option value="Male" <?= ($student['gender'] === 'Male') ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= ($student['gender'] === 'Female') ? 'selected' : '' ?>>Female</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= e($student['date_of_birth']) ?>">
                        </div>
                    </div>

                    <h5 class="fw-bold text-primary mb-3">2. Parent / Guardian Contact</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Parent Name</label>
                            <input type="text" name="parent_name" class="form-control" value="<?= e($student['parent_name']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Parent Phone</label>
                            <input type="text" name="parent_phone" class="form-control" value="<?= e($student['parent_phone']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Parent Email</label>
                            <input type="email" name="parent_email" class="form-control" value="<?= e($student['parent_email']) ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small">Residential Address</label>
                            <textarea name="address" class="form-control" rows="2"><?= e($student['residential_address']) ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-primary px-4 fw-semibold">
                            <i class="bi bi-check2-circle me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
