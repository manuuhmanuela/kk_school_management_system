<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$id = intval($_GET['id'] ?? 0);
$pdo = get_db_connection();

$stmt = $pdo->prepare("SELECT s.*, c.name as class_name, c.stream FROM students s JOIN classes c ON s.current_class_id = c.id WHERE s.id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    set_flash('danger', 'Student record not found.');
    redirect('students/index.php');
}

// Fetch historical marks
$marks_stmt = $pdo->prepare("
    SELECT m.score, m.is_absent, a.name as assessment_name, a.academic_year, a.term, sub.subject_name, sub.subject_code 
    FROM marks m 
    JOIN assessments a ON m.assessment_id = a.id 
    JOIN subjects sub ON m.subject_id = sub.id 
    WHERE m.student_id = ? 
    ORDER BY a.academic_year DESC, a.term DESC, sub.subject_name ASC
");
$marks_stmt->execute([$id]);
$student_marks = $marks_stmt->fetchAll();

// Fetch fee transactions
$fees_stmt = $pdo->prepare("SELECT * FROM fee_payments WHERE student_id = ? ORDER BY payment_date DESC");
$fees_stmt->execute([$id]);
$student_fees = $fees_stmt->fetchAll();

// Fetch progression and transfer history
$prog_stmt = $pdo->prepare("
    SELECT p.*, fc.name as from_class, tc.name as to_class, u.full_name as recorded_by_name 
    FROM student_progression p 
    JOIN classes fc ON p.from_class_id = fc.id 
    LEFT JOIN classes tc ON p.to_class_id = tc.id 
    LEFT JOIN users u ON p.recorded_by = u.id 
    WHERE p.student_id = ? 
    ORDER BY p.action_date DESC
");
$prog_stmt->execute([$id]);
$progression_history = $prog_stmt->fetchAll();

$page_title = 'Student Profile: ' . $student['first_name'] . ' ' . $student['last_name'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Student Profile</h3>
        <p class="text-muted mb-0">Admission No: <strong class="text-primary"><?= e($student['admission_no']) ?></strong></p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>students/index.php" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Back
        </a>
        <a href="<?= BASE_URL ?>reports/print_card.php?student_id=<?= $student['id'] ?>" target="_blank" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-printer me-1"></i> Print Report Card
        </a>
        <a href="<?= BASE_URL ?>students/edit.php?id=<?= $student['id'] ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-pencil-square me-1"></i> Edit Biodata
        </a>
    </div>
</div>

<div class="row g-4">
    <!-- Student Information Column -->
    <div class="col-lg-4">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body text-center p-4">
                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3 shadow" style="width: 80px; height: 80px; font-size: 2rem; font-weight: bold;">
                    <?= strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)) ?>
                </div>
                <h4 class="fw-bold mb-1"><?= e($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['last_name']) ?></h4>
                <p class="text-muted mb-2">Adm: <strong><?= e($student['admission_no']) ?></strong></p>
                <span class="badge <?= ($student['division'] === 'Primary') ? 'bg-primary' : 'bg-warning text-dark' ?> fs-6 px-3 py-1">
                    <?= e($student['division']) ?> School (<?= e($student['class_name']) ?>)
                </span>
            </div>
            <ul class="list-group list-group-flush border-top">
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                    <span class="text-muted small">Status:</span>
                    <span class="badge bg-success"><?= e($student['status']) ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                    <span class="text-muted small">Gender:</span>
                    <span class="fw-semibold"><?= e($student['gender']) ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                    <span class="text-muted small">Date of Birth:</span>
                    <span class="fw-semibold"><?= e($student['date_of_birth'] ?? 'Not Set') ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                    <span class="text-muted small">Stream:</span>
                    <span class="fw-semibold"><?= e($student['stream']) ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                    <span class="text-muted small">Admission Date:</span>
                    <span class="fw-semibold"><?= e($student['admission_date'] ?? 'N/A') ?></span>
                </li>
            </ul>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold">
                <i class="bi bi-people me-1 text-primary"></i> Parent / Guardian Contact
            </div>
            <div class="card-body">
                <p class="mb-1"><small class="text-muted">Parent Name:</small><br><strong><?= e($student['parent_name'] ?? 'None recorded') ?></strong></p>
                <p class="mb-1"><small class="text-muted">Phone Number:</small><br><strong><?= e($student['parent_phone'] ?? 'None recorded') ?></strong></p>
                <p class="mb-1"><small class="text-muted">Email:</small><br><?= e($student['parent_email'] ?? 'None') ?></p>
                <p class="mb-0"><small class="text-muted">Residential Address:</small><br><?= nl2br(e($student['residential_address'] ?? 'Not specified')) ?></p>
            </div>
        </div>
    </div>

    <!-- Academic and Financial Details Column -->
    <div class="col-lg-8">
        <!-- Tabs -->
        <ul class="nav nav-tabs fw-semibold mb-3" id="profileTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="academic-tab" data-bs-toggle="tab" data-bs-target="#academic-tab-pane" type="button" role="tab">
                    <i class="bi bi-journal-check me-1"></i> Academic Marks History
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="fees-tab" data-bs-toggle="tab" data-bs-target="#fees-tab-pane" type="button" role="tab">
                    <i class="bi bi-cash-coin me-1"></i> Fee Transactions
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="prog-tab" data-bs-toggle="tab" data-bs-target="#prog-tab-pane" type="button" role="tab">
                    <i class="bi bi-clock-history me-1"></i> Progression & Transfer History
                </button>
            </li>
        </ul>

        <div class="tab-content" id="profileTabContent">
            <!-- Academic Marks -->
            <div class="tab-pane fade show active" id="academic-tab-pane" role="tabpanel">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Academic Year & Term</th>
                                        <th>Assessment</th>
                                        <th>Subject</th>
                                        <th>Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($student_marks)): ?>
                                        <tr>
                                            <td colspan="4" class="text-center py-4 text-muted">No assessment scores entered yet for this learner.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($student_marks as $m): ?>
                                            <tr>
                                                <td><?= e($m['academic_year']) ?> - <?= e($m['term']) ?></td>
                                                <td><span class="badge bg-light text-dark border"><?= e($m['assessment_name']) ?></span></td>
                                                <td><?= e($m['subject_name']) ?></td>
                                                <td>
                                                    <?php if ($m['is_absent']): ?>
                                                        <span class="badge bg-danger">Absent</span>
                                                    <?php else: ?>
                                                        <strong class="text-primary"><?= number_format($m['score'], 1) ?></strong>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Fee Payments -->
            <div class="tab-pane fade" id="fees-tab-pane" role="tabpanel">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Receipt #</th>
                                        <th>Date</th>
                                        <th>Term</th>
                                        <th>Method & Ref</th>
                                        <th>Amount</th>
                                        <th class="text-end">Print</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($student_fees)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-4 text-muted">No fee payments recorded.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($student_fees as $f): ?>
                                            <tr>
                                                <td class="fw-bold"><?= e($f['receipt_no']) ?></td>
                                                <td><?= e($f['payment_date']) ?></td>
                                                <td><?= e($f['term']) ?> (<?= e($f['academic_year']) ?>)</td>
                                                <td><?= e($f['payment_method']) ?> <?= e($f['reference_no'] ? "({$f['reference_no']})" : '') ?></td>
                                                <td class="fw-bold text-success">KES <?= number_format($f['amount_paid'], 2) ?></td>
                                                <td class="text-end">
                                                    <a href="<?= BASE_URL ?>fees/receipt.php?id=<?= $f['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary py-0">
                                                        <i class="bi bi-printer"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Progression & Transfers -->
            <div class="tab-pane fade" id="prog-tab-pane" role="tabpanel">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Action</th>
                                        <th>From Class</th>
                                        <th>To Class</th>
                                        <th>Academic Year</th>
                                        <th>Remarks</th>
                                        <th>Recorded By</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($progression_history)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-4 text-muted">No promotion or transfer events recorded for this learner.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($progression_history as $ph): ?>
                                            <tr>
                                                <td><span class="badge bg-info text-dark"><?= e($ph['action_type']) ?></span></td>
                                                <td><?= e($ph['from_class']) ?></td>
                                                <td><?= e($ph['to_class'] ?? 'N/A') ?></td>
                                                <td><?= e($ph['academic_year']) ?></td>
                                                <td><?= e($ph['remarks']) ?></td>
                                                <td class="small text-muted"><?= e($ph['recorded_by_name'] ?? 'System') ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
