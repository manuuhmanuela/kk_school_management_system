<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$division = get_active_division();

$assessment_id = intval($_GET['assessment_id'] ?? 0);
$class_id      = intval($_GET['class_id'] ?? 0);

// Fetch assessments
$assessments = $pdo->query("SELECT id, name, term, academic_year, max_marks FROM assessments ORDER BY id DESC")->fetchAll();
if (!$assessment_id && !empty($assessments)) {
    $assessment_id = $assessments[0]['id'];
}

// Fetch classes
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();
if (!$class_id && !empty($classes)) {
    $class_id = $classes[0]['id'];
}

// Current Assessment & Class info
$curr_assessment = null;
foreach ($assessments as $a) {
    if ($a['id'] == $assessment_id) $curr_assessment = $a;
}
$curr_class = null;
foreach ($classes as $c) {
    if ($c['id'] == $class_id) $curr_class = $c;
}

// Fetch all subjects for this class's division
$class_div = $curr_class['division'] ?? 'Primary';
$subjects = $pdo->query("SELECT id, subject_name, subject_code FROM subjects WHERE division = '{$class_div}' OR division = 'Both' ORDER BY subject_name ASC")->fetchAll();

// Fetch learners and their marks
$students_stmt = $pdo->prepare("SELECT id, admission_no, first_name, last_name FROM students WHERE current_class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$students_stmt->execute([$class_id]);
$students = $students_stmt->fetchAll();

// Compile learner performance
$ranked_students = [];
$subject_scores = []; // for subject performance analysis
$non_sitters = [];

foreach ($students as $st) {
    $marks_stmt = $pdo->prepare("SELECT subject_id, score, is_absent FROM marks WHERE assessment_id = ? AND student_id = ?");
    $marks_stmt->execute([$assessment_id, $st['id']]);
    $student_scores = [];
    $total_score = 0;
    $subjects_sat = 0;
    $has_absent = false;

    while ($row = $marks_stmt->fetch()) {
        $student_scores[$row['subject_id']] = $row;
        if ($row['is_absent'] == 1 || $row['score'] === null) {
            $has_absent = true;
        } else {
            $score = floatval($row['score']);
            $total_score += $score;
            $subjects_sat++;

            // Accumulate for subject statistics
            $subject_scores[$row['subject_id']][] = [
                'score' => $score,
                'student' => $st['first_name'] . ' ' . $st['last_name']
            ];
        }
    }

    $avg = ($subjects_sat > 0) ? round($total_score / $subjects_sat, 1) : 0;

    // Grading Scale (Kenya Primary/Junior School standard)
    // 80-100: Exceeding Expectations (EE / A)
    // 65-79: Meeting Expectations (ME / B)
    // 50-64: Approaching Expectations (AE / C)
    // Below 50: Below Expectations (BE / D)
    if ($avg >= 80) $grade = 'EE (Exceeding)';
    elseif ($avg >= 65) $grade = 'ME (Meeting)';
    elseif ($avg >= 50) $grade = 'AE (Approaching)';
    else $grade = 'BE (Below)';

    $ranked_students[] = [
        'student' => $st,
        'scores' => $student_scores,
        'total' => $total_score,
        'average' => $avg,
        'grade' => $grade,
        'subjects_sat' => $subjects_sat
    ];

    if ($subjects_sat === 0 || $has_absent) {
        $non_sitters[] = $st;
    }
}

// Sort by average descending to compute rankings
usort($ranked_students, function ($a, $b) {
    return $b['average'] <=> $a['average'];
});

// Calculate Class Average
$class_total_avg = 0;
if (count($ranked_students) > 0) {
    $sum_avgs = array_sum(array_column($ranked_students, 'average'));
    $class_total_avg = round($sum_avgs / count($ranked_students), 1);
}

$page_title = 'Academic Performance Analysis';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Academic Performance Analysis</h3>
        <p class="text-muted mb-0">Class ranking, subject champions, non-sitters & comparative metrics</p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i> Print Merit List
        </button>
        <a href="<?= BASE_URL ?>reports/index.php?assessment_id=<?= $assessment_id ?>&class_id=<?= $class_id ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-file-earmark-pdf me-1"></i> Class Report Cards
        </a>
    </div>
</div>

<!-- Assessment / Class Filter -->
<div class="card shadow-sm border-0 mb-4 d-print-none">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Assessment</label>
                <select name="assessment_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($assessments as $a): ?>
                        <option value="<?= $a['id'] ?>" <?= ($assessment_id == $a['id']) ? 'selected' : '' ?>>
                            <?= e($a['name']) ?> (<?= e($a['term']) ?> <?= e($a['academic_year']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Class / Grade</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($class_id == $c['id']) ? 'selected' : '' ?>>
                            [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Analyze</button>
            </div>
        </form>
    </div>
</div>

<!-- Class Performance Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Class Mean Score</span>
            <h3 class="fw-bold text-primary mt-1 mb-0"><?= $class_total_avg ?>%</h3>
            <small class="text-muted"><?= e($curr_class['name'] ?? '') ?> Overall Average</small>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Top Learner Score</span>
            <h3 class="fw-bold text-success mt-1 mb-0"><?= !empty($ranked_students) ? $ranked_students[0]['average'] : 0 ?>%</h3>
            <small class="text-success"><?= !empty($ranked_students) ? e($ranked_students[0]['student']['first_name']) : 'None' ?></small>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Total Candidature</span>
            <h3 class="fw-bold text-dark mt-1 mb-0"><?= count($students) ?> Learners</h3>
            <small class="text-muted">Registered in Grade</small>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Incomplete / Non-Sitters</span>
            <h3 class="fw-bold text-warning mt-1 mb-0"><?= count($non_sitters) ?></h3>
            <small class="text-warning">Missed one or more papers</small>
        </div>
    </div>
</div>

<!-- Merit Rankings Table -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold text-dark">
            <i class="bi bi-trophy me-2 text-warning"></i>Class Performance & Merit Ranking (<?= e($curr_class['name'] ?? '') ?>)
        </h6>
        <span class="badge bg-light text-dark border"><?= e($curr_assessment['name'] ?? '') ?></span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle mb-0 text-center">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;">Rank</th>
                        <th class="text-start">Adm No</th>
                        <th class="text-start">Learner Name</th>
                        <?php foreach ($subjects as $s): ?>
                            <th title="<?= e($s['subject_name']) ?>"><?= e($s['subject_code']) ?></th>
                        <?php endforeach; ?>
                        <th>Total</th>
                        <th>Average</th>
                        <th>Remarks / Level</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($ranked_students)): ?>
                        <tr>
                            <td colspan="<?= count($subjects) + 6 ?>" class="py-5 text-muted">No marks recorded yet for this class and assessment.</td>
                        </tr>
                    <?php else: ?>
                        <?php 
                        $rank = 1;
                        foreach ($ranked_students as $entry): 
                            $st = $entry['student'];
                        ?>
                            <tr>
                                <td>
                                    <?php if ($rank === 1): ?>
                                        <span class="badge bg-warning text-dark"><i class="bi bi-trophy-fill"></i> 1</span>
                                    <?php elseif ($rank === 2): ?>
                                        <span class="badge bg-secondary-subtle text-secondary border">2</span>
                                    <?php elseif ($rank === 3): ?>
                                        <span class="badge bg-danger-subtle text-danger border">3</span>
                                    <?php else: ?>
                                        <span class="fw-bold text-muted"><?= $rank ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-start fw-bold text-primary"><?= e($st['admission_no']) ?></td>
                                <td class="text-start fw-semibold"><?= e($st['first_name'] . ' ' . $st['last_name']) ?></td>
                                
                                <?php foreach ($subjects as $s): 
                                    $sub_mark = $entry['scores'][$s['id']] ?? null;
                                    $score_disp = '-';
                                    if ($sub_mark) {
                                        if ($sub_mark['is_absent']) {
                                            $score_disp = '<span class="badge bg-danger">X</span>';
                                        } elseif ($sub_mark['score'] !== null) {
                                            $score_disp = number_format($sub_mark['score'], 0);
                                        }
                                    }
                                ?>
                                    <td><?= $score_disp ?></td>
                                <?php endforeach; ?>

                                <td class="fw-bold"><?= number_format($entry['total'], 0) ?></td>
                                <td class="fw-bold text-primary fs-6"><?= $entry['average'] ?>%</td>
                                <td>
                                    <?php 
                                    $badge = 'bg-success';
                                    if (strpos($entry['grade'], 'Approaching') !== false) $badge = 'bg-warning text-dark';
                                    if (strpos($entry['grade'], 'Below') !== false) $badge = 'bg-danger';
                                    ?>
                                    <span class="badge <?= $badge ?>"><?= e($entry['grade']) ?></span>
                                </td>
                            </tr>
                        <?php 
                            $rank++;
                        endforeach; 
                        ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Subject Champions Grid -->
<div class="row g-4">
    <div class="col-lg-12">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold">
                <i class="bi bi-award-fill me-2 text-warning"></i>Subject Champions (Highest Scoring Learners per Subject)
            </div>
            <div class="card-body p-3">
                <div class="row g-3">
                    <?php foreach ($subjects as $s): 
                        $scores = $subject_scores[$s['id']] ?? [];
                        $champion = 'No data';
                        $max_score = 0;
                        if (!empty($scores)) {
                            usort($scores, fn($a, $b) => $b['score'] <=> $a['score']);
                            $champion = $scores[0]['student'];
                            $max_score = $scores[0]['score'];
                        }
                    ?>
                        <div class="col-md-3">
                            <div class="border rounded p-3 bg-light">
                                <div class="text-muted small fw-semibold"><?= e($s['subject_name']) ?></div>
                                <h5 class="fw-bold text-primary mb-1 mt-1"><?= $champion ?></h5>
                                <span class="badge bg-success">Top Score: <?= $max_score ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
