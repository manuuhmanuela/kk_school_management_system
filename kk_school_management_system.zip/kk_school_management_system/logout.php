<?php
require_once __DIR__ . '/config/init.php';

if (is_logged_in()) {
    log_audit('User Logout', "User {$_SESSION['user']['username']} signed out.");
}

// Clear session securely
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

// Redirect cleanly to login
header("Location: " . BASE_URL . "login.php");
exit;
