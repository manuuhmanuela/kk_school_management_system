<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$class_id = intval($_GET['class_id'] ?? 0);
$date     = !empty($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Fetch classes
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();
if (!$class_id && !empty($classes)) {
    $class_id = $classes[0]['id'];
}

// Handle Attendance Save BEFORE any HTML output
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {
    $attendance = $_POST['status'] ?? [];
    $remarks    = $_POST['remarks'] ?? [];

    $stmt = $pdo->prepare("
        INSERT INTO attendance (student_id, class_id, attendance_date, status, remarks, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            status = VALUES(status),
            remarks = VALUES(remarks),
            recorded_by = VALUES(recorded_by)
    ");

    $count = 0;
    foreach ($attendance as $student_id => $status) {
        $st_id = intval($student_id);
        $rem = trim($remarks[$st_id] ?? '');
        $stmt->execute([
            $st_id,
            $class_id,
            $date,
            $status,
            $rem,
            $_SESSION['user_id']
        ]);
        $count++;
    }

    log_audit('Attendance Marked', "Marked roll call for Class ID {$class_id} on {$date} ({$count} learners)");
    set_flash('success', "Roll call successfully saved for {$count} learners!");
    redirect("attendance/index.php?class_id={$class_id}&date={$date}");
}

// Fetch students
$st_stmt = $pdo->prepare("SELECT id, admission_no, first_name, last_name FROM students WHERE current_class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$st_stmt->execute([$class_id]);
$students = $st_stmt->fetchAll();

// Existing attendance
$att_stmt = $pdo->prepare("SELECT student_id, status, remarks FROM attendance WHERE class_id = ? AND attendance_date = ?");
$att_stmt->execute([$class_id, $date]);
$existing = [];
while ($row = $att_stmt->fetch()) {
    $existing[$row['student_id']] = $row;
}

$page_title = 'Mark Daily Attendance';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Mark Classroom Roll Call</h3>
        <p class="text-muted mb-0">Record daily morning or afternoon student presence</p>
    </div>
    <a href="<?= BASE_URL ?>attendance/index.php?class_id=<?= $class_id ?>&date=<?= $date ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back to Register
    </a>
</div>

<!-- Date / Class selector -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Class / Grade</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($class_id == $c['id']) ? 'selected' : '' ?>>
                            [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Date</label>
                <input type="date" name="date" class="form-control form-control-sm" value="<?= e($date) ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Load</button>
            </div>
        </form>
    </div>
</div>

<form method="POST" action="">
    <input type="hidden" name="save_attendance" value="1">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h6 class="mb-0 fw-bold"><i class="bi bi-ui-checks me-2 text-primary"></i>Roll Call Sheet &bull; <?= date('d M Y', strtotime($date)) ?></h6>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-success btn-sm" onclick="markAll('Present')">
                    <i class="bi bi-check-all"></i> Mark All Present
                </button>
                <button type="submit" class="btn btn-success btn-sm px-4 fw-bold">
                    <i class="bi bi-save me-1"></i> Save Roll Call
                </button>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th style="width: 180px;">Adm No</th>
                            <th>Student Name</th>
                            <th style="width: 320px;">Attendance Status</th>
                            <th>Remarks (Optional)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">No learners found in this class.</td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $i = 1;
                            foreach ($students as $st): 
                                $curr = $existing[$st['id']] ?? null;
                                $curr_status = $curr['status'] ?? 'Present';
                                $curr_rem = $curr['remarks'] ?? '';
                            ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td class="fw-bold text-primary"><?= e($st['admission_no']) ?></td>
                                    <td class="fw-semibold"><?= e($st['first_name'] . ' ' . $st['last_name']) ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm w-100" role="group">
                                            <input type="radio" class="btn-check att-status" name="status[<?= $st['id'] ?>]" id="pres_<?= $st['id'] ?>" value="Present" <?= ($curr_status === 'Present') ? 'checked' : '' ?>>
                                            <label class="btn btn-outline-success" for="pres_<?= $st['id'] ?>">Present</label>

                                            <input type="radio" class="btn-check att-status" name="status[<?= $st['id'] ?>]" id="abs_<?= $st['id'] ?>" value="Absent" <?= ($curr_status === 'Absent') ? 'checked' : '' ?>>
                                            <label class="btn btn-outline-danger" for="abs_<?= $st['id'] ?>">Absent</label>

                                            <input type="radio" class="btn-check att-status" name="status[<?= $st['id'] ?>]" id="exc_<?= $st['id'] ?>" value="Excused" <?= ($curr_status === 'Excused') ? 'checked' : '' ?>>
                                            <label class="btn btn-outline-info" for="exc_<?= $st['id'] ?>">Excused</label>

                                            <input type="radio" class="btn-check att-status" name="status[<?= $st['id'] ?>]" id="late_<?= $st['id'] ?>" value="Late" <?= ($curr_status === 'Late') ? 'checked' : '' ?>>
                                            <label class="btn btn-outline-warning" for="late_<?= $st['id'] ?>">Late</label>
                                        </div>
                                    </td>
                                    <td>
                                        <input type="text" name="remarks[<?= $st['id'] ?>]" class="form-control form-control-sm" placeholder="e.g. Doctor's appointment" value="<?= e($curr_rem) ?>">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if (!empty($students)): ?>
            <div class="card-footer bg-light p-3 text-end">
                <button type="submit" class="btn btn-success px-4 fw-bold shadow-sm">
                    <i class="bi bi-check2-circle me-1"></i> Save Roll Call
                </button>
            </div>
        <?php endif; ?>
    </div>
</form>

<script>
function markAll(status) {
    if (status === 'Present') {
        document.querySelectorAll('input[type="radio"][value="Present"]').forEach(r => r.checked = true);
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
