<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$division = get_active_division();

$class_id = intval($_GET['class_id'] ?? 0);
$date     = !empty($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Fetch classes
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();
if (!$class_id && !empty($classes)) {
    $class_id = $classes[0]['id'];
}

// Fetch students
$st_stmt = $pdo->prepare("SELECT id, admission_no, first_name, last_name FROM students WHERE current_class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$st_stmt->execute([$class_id]);
$students = $st_stmt->fetchAll();

// Fetch attendance on this date
$att_stmt = $pdo->prepare("SELECT student_id, status, remarks FROM attendance WHERE class_id = ? AND attendance_date = ?");
$att_stmt->execute([$class_id, $date]);
$attendance_data = [];
while ($row = $att_stmt->fetch()) {
    $attendance_data[$row['student_id']] = $row;
}

// Summary counts
$present_count = 0;
$absent_count = 0;
foreach ($attendance_data as $att) {
    if ($att['status'] === 'Present') $present_count++;
    if ($att['status'] === 'Absent') $absent_count++;
}

$page_title = 'Attendance Register';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Student Attendance Register</h3>
        <p class="text-muted mb-0">Daily classroom roll call, monitoring, and absentee reporting</p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i> Print Register
        </button>
        <a href="<?= BASE_URL ?>attendance/mark.php?class_id=<?= $class_id ?>&date=<?= $date ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-check2-square me-1"></i> Mark Today's Roll Call
        </a>
    </div>
</div>

<!-- Filter -->
<div class="card shadow-sm border-0 mb-4 d-print-none">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Class / Grade</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($class_id == $c['id']) ? 'selected' : '' ?>>
                            [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Attendance Date</label>
                <input type="date" name="date" class="form-control form-control-sm" value="<?= e($date) ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Load Register</button>
            </div>
        </form>
    </div>
</div>

<!-- Attendance Stats -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Total Learners In Class</span>
            <h3 class="fw-bold text-dark mt-1 mb-0"><?= count($students) ?></h3>
            <small class="text-muted">Enrolled on register</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Present on <?= date('d M Y', strtotime($date)) ?></span>
            <h3 class="fw-bold text-success mt-1 mb-0"><?= $present_count ?></h3>
            <small class="text-success"><?= (count($students) > 0) ? round(($present_count / count($students)) * 100, 1) : 0 ?>% Attendance Rate</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Absent / Excused</span>
            <h3 class="fw-bold text-danger mt-1 mb-0"><?= $absent_count ?></h3>
            <small class="text-danger">Documented absentees</small>
        </div>
    </div>
</div>

<!-- Table -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold"><i class="bi bi-calendar-check me-2 text-primary"></i>Daily Register &bull; Date: <?= date('D, d M Y', strtotime($date)) ?></h6>
        <a href="<?= BASE_URL ?>attendance/mark.php?class_id=<?= $class_id ?>&date=<?= $date ?>" class="btn btn-sm btn-link">Edit Roll Call</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>Admission No</th>
                        <th>Learner Full Name</th>
                        <th>Status</th>
                        <th>Remarks / Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">No learners found in this class.</td>
                        </tr>
                    <?php else: ?>
                        <?php 
                        $i = 1;
                        foreach ($students as $st): 
                            $att = $attendance_data[$st['id']] ?? null;
                            $status = $att['status'] ?? 'Unmarked';
                            $remarks = $att['remarks'] ?? '';
                        ?>
                            <tr>
                                <td><?= $i++ ?></td>
                                <td class="fw-bold text-primary"><?= e($st['admission_no']) ?></td>
                                <td class="fw-semibold"><?= e($st['first_name'] . ' ' . $st['last_name']) ?></td>
                                <td>
                                    <?php if ($status === 'Present'): ?>
                                        <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i> Present</span>
                                    <?php elseif ($status === 'Absent'): ?>
                                        <span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i> Absent</span>
                                    <?php elseif ($status === 'Excused'): ?>
                                        <span class="badge bg-info text-dark">Excused / Sick</span>
                                    <?php elseif ($status === 'Late'): ?>
                                        <span class="badge bg-warning text-dark">Late</span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-muted border">Not Recorded</span>
                                    <?php endif; ?>
                                </td>
                                <td><small class="text-muted"><?= e($remarks ?: '&mdash;') ?></small></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
