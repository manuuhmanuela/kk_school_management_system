-- KK School Management System Database Schema
-- Schools: KOMBE AIC PRIMARY SCHOOL & KOMBE AIC JUNIOR SCHOOL

CREATE DATABASE IF NOT EXISTS `kk_school_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `kk_school_db`;

-- 1. Users & Roles
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `role` ENUM('Owner', 'Administrator', 'Head Teacher', 'Deputy Head Teacher', 'Director of Studies', 'Teacher') NOT NULL DEFAULT 'Teacher',
    `assigned_division` ENUM('All', 'Primary', 'Junior') NOT NULL DEFAULT 'All',
    `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Divisions & Classes
CREATE TABLE IF NOT EXISTS `classes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL, -- e.g. Grade 4, Grade 5, Grade 6, Grade 7, Grade 8, Grade 9
    `division` ENUM('Primary', 'Junior') NOT NULL,
    `stream` VARCHAR(20) DEFAULT 'Main', -- e.g. East, West, Main
    `class_teacher_id` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`class_teacher_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 3. Subjects
CREATE TABLE IF NOT EXISTS `subjects` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `subject_code` VARCHAR(20) NOT NULL UNIQUE,
    `subject_name` VARCHAR(100) NOT NULL,
    `division` ENUM('Primary', 'Junior', 'Both') NOT NULL DEFAULT 'Both',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Teacher Subject Allocation
CREATE TABLE IF NOT EXISTS `teacher_allocations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `teacher_id` INT NOT NULL,
    `class_id` INT NOT NULL,
    `subject_id` INT NOT NULL,
    `academic_year` VARCHAR(10) NOT NULL DEFAULT '2026',
    FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Students
CREATE TABLE IF NOT EXISTS `students` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `admission_no` VARCHAR(30) NOT NULL UNIQUE,
    `first_name` VARCHAR(50) NOT NULL,
    `middle_name` VARCHAR(50) DEFAULT NULL,
    `last_name` VARCHAR(50) NOT NULL,
    `gender` ENUM('Male', 'Female', 'Other') NOT NULL,
    `date_of_birth` DATE DEFAULT NULL,
    `current_class_id` INT NOT NULL,
    `division` ENUM('Primary', 'Junior') NOT NULL,
    `parent_name` VARCHAR(100) DEFAULT NULL,
    `parent_phone` VARCHAR(25) DEFAULT NULL,
    `parent_email` VARCHAR(100) DEFAULT NULL,
    `residential_address` TEXT DEFAULT NULL,
    `status` ENUM('Active', 'Promoted', 'Transferred', 'Graduated', 'Alumni', 'Demoted') NOT NULL DEFAULT 'Active',
    `admission_date` DATE DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`current_class_id`) REFERENCES `classes`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 6. Progression & Transfer History
CREATE TABLE IF NOT EXISTS `student_progression` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `from_class_id` INT NOT NULL,
    `to_class_id` INT DEFAULT NULL,
    `action_type` ENUM('Promotion', 'Demotion', 'Transfer_Out', 'Primary_to_Junior', 'Graduation') NOT NULL,
    `academic_year` VARCHAR(10) NOT NULL,
    `remarks` TEXT DEFAULT NULL,
    `action_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `recorded_by` INT DEFAULT NULL,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`from_class_id`) REFERENCES `classes`(`id`),
    FOREIGN KEY (`to_class_id`) REFERENCES `classes`(`id`),
    FOREIGN KEY (`recorded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 7. Assessments & Examinations
CREATE TABLE IF NOT EXISTS `assessments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL, -- e.g. Term 1 CAT 1, Term 1 Mid-Term, Term 1 End-Term, Weekly Test 1, Mock Exam
    `type` ENUM('CAT', 'Weekly Test', 'Mid-Term', 'End-Term', 'Mock') NOT NULL,
    `division` ENUM('Primary', 'Junior', 'Both') NOT NULL DEFAULT 'Both',
    `academic_year` VARCHAR(10) NOT NULL DEFAULT '2026',
    `term` ENUM('Term 1', 'Term 2', 'Term 3') NOT NULL DEFAULT 'Term 1',
    `max_marks` DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    `is_published` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 8. Assessment Marks
CREATE TABLE IF NOT EXISTS `marks` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `assessment_id` INT NOT NULL,
    `student_id` INT NOT NULL,
    `class_id` INT NOT NULL,
    `subject_id` INT NOT NULL,
    `score` DECIMAL(5,2) DEFAULT NULL, -- NULL indicates non-sitter
    `is_absent` TINYINT(1) DEFAULT 0,
    `teacher_comment` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`assessment_id`) REFERENCES `assessments`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_student_assessment_subject` (`assessment_id`, `student_id`, `subject_id`)
) ENGINE=InnoDB;

-- 9. Attendance
CREATE TABLE IF NOT EXISTS `attendance` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `class_id` INT NOT NULL,
    `attendance_date` DATE NOT NULL,
    `status` ENUM('Present', 'Absent', 'Excused', 'Late') NOT NULL DEFAULT 'Present',
    `remarks` VARCHAR(255) DEFAULT NULL,
    `recorded_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`recorded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    UNIQUE KEY `unique_student_attendance_date` (`student_id`, `attendance_date`)
) ENGINE=InnoDB;

-- 10. Fee Structures
CREATE TABLE IF NOT EXISTS `fee_structures` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `division` ENUM('Primary', 'Junior') NOT NULL,
    `class_id` INT DEFAULT NULL, -- NULL means applicable to all in division
    `academic_year` VARCHAR(10) NOT NULL DEFAULT '2026',
    `term` ENUM('Term 1', 'Term 2', 'Term 3') NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `description` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 11. Fee Payments
CREATE TABLE IF NOT EXISTS `fee_payments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `receipt_no` VARCHAR(50) NOT NULL UNIQUE,
    `student_id` INT NOT NULL,
    `amount_paid` DECIMAL(10,2) NOT NULL,
    `payment_method` ENUM('Cash', 'M-Pesa', 'Bank Deposit', 'Cheque') NOT NULL DEFAULT 'Cash',
    `reference_no` VARCHAR(100) DEFAULT NULL,
    `payment_date` DATE NOT NULL,
    `term` ENUM('Term 1', 'Term 2', 'Term 3') NOT NULL DEFAULT 'Term 1',
    `academic_year` VARCHAR(10) NOT NULL DEFAULT '2026',
    `received_by` INT DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`received_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 12. Food & In-Kind Contributions (Stock & Collection)
CREATE TABLE IF NOT EXISTS `food_collections` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `item_name` VARCHAR(100) NOT NULL, -- e.g. Maize (90kg bag), Beans, Rice, Cooking Oil
    `category` ENUM('Grain', 'Legume', 'Oil', 'Vegetables', 'Other') NOT NULL DEFAULT 'Grain',
    `quantity` DECIMAL(10,2) NOT NULL,
    `unit` VARCHAR(20) NOT NULL DEFAULT 'kg', -- kg, bags, liters
    `contributed_by_student_id` INT DEFAULT NULL, -- if student brought food in lieu of/for lunch fee
    `contributor_name` VARCHAR(100) DEFAULT NULL,
    `status` ENUM('In Stock', 'Disbursed', 'Damaged') NOT NULL DEFAULT 'In Stock',
    `collection_date` DATE NOT NULL,
    `recorded_by` INT DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`contributed_by_student_id`) REFERENCES `students`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`recorded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 13. System Activity Logs / Audit
CREATE TABLE IF NOT EXISTS `audit_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(50) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 14. Seed Initial Data
-- Default Users: password for all initial accounts is: admin123
-- Hashes generated via password_hash('admin123', PASSWORD_BCRYPT)
INSERT INTO `users` (`username`, `password_hash`, `full_name`, `email`, `phone`, `role`, `assigned_division`, `status`) VALUES
('admin', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'System Administrator', 'admin@kombeschools.sc.ke', '0711000111', 'Administrator', 'All', 'Active'),
('owner', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'Director / School Owner', 'director@kombeschools.sc.ke', '0711000222', 'Owner', 'All', 'Active'),
('headteacher_pri', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'Mr. Peter Mutua', 'head.primary@kombeschools.sc.ke', '0711000333', 'Head Teacher', 'Primary', 'Active'),
('headteacher_jun', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'Mrs. Grace Wanjiku', 'head.junior@kombeschools.sc.ke', '0711000444', 'Head Teacher', 'Junior', 'Active'),
('dos_user', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'Director of Studies (DOS)', 'dos@kombeschools.sc.ke', '0711000555', 'Director of Studies', 'All', 'Active'),
('teacher_john', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'Mr. John Ochieng', 'john.o@kombeschools.sc.ke', '0711000666', 'Teacher', 'Primary', 'Active'),
('teacher_mary', '$2y$10$w0jWqP5i4E6tQy9FqK/7uOhM9z71kU4z7p2mF2J7tG3c/R6u9a5cW', 'Ms. Mary Mwangi', 'mary.m@kombeschools.sc.ke', '0711000777', 'Teacher', 'Junior', 'Active');

-- Primary (Grades 4-6) and Junior (Grades 7-9) Classes
INSERT INTO `classes` (`name`, `division`, `stream`, `class_teacher_id`) VALUES
('Grade 4', 'Primary', 'East', 6),
('Grade 5', 'Primary', 'Main', 6),
('Grade 6', 'Primary', 'Main', 6),
('Grade 7', 'Junior', 'East', 7),
('Grade 8', 'Junior', 'West', 7),
('Grade 9', 'Junior', 'Main', 7);

-- Primary and Junior Subjects
INSERT INTO `subjects` (`subject_code`, `subject_name`, `division`) VALUES
('MATH_PRI', 'Mathematics (Primary)', 'Primary'),
('ENG_PRI', 'English Language', 'Primary'),
('KISW_PRI', 'Kiswahili', 'Primary'),
('SCI_PRI', 'Science & Technology', 'Primary'),
('SOC_PRI', 'Social Studies', 'Primary'),
('CRE_PRI', 'C.R.E', 'Primary'),
('AGR_PRI', 'Agriculture & Nutrition', 'Primary'),
('MATH_JUN', 'Mathematics (Junior)', 'Junior'),
('ENG_JUN', 'English', 'Junior'),
('KISW_JUN', 'Kiswahili', 'Junior'),
('INT_SCI', 'Integrated Science', 'Junior'),
('SOC_JUN', 'Social Studies', 'Junior'),
('CRE_JUN', 'C.R.E / Religious Education', 'Junior'),
('PRE_TECH', 'Pre-Technical Studies', 'Junior'),
('AGR_JUN', 'Agriculture', 'Junior'),
('BUS_JUN', 'Business Studies', 'Junior');

-- Sample Students
INSERT INTO `students` (`admission_no`, `first_name`, `middle_name`, `last_name`, `gender`, `date_of_birth`, `current_class_id`, `division`, `parent_name`, `parent_phone`, `status`, `admission_date`) VALUES
('KK/PRI/2024/001', 'Emmanuel', 'Kiptoo', 'Koech', 'Male', '2014-05-12', 1, 'Primary', 'David Koech', '0722111001', 'Active', '2024-01-08'),
('KK/PRI/2024/002', 'Faith', 'Chebet', 'Rotich', 'Female', '2014-08-20', 1, 'Primary', 'Sarah Rotich', '0722111002', 'Active', '2024-01-08'),
('KK/PRI/2024/003', 'Brian', 'Mwenda', 'Kariuki', 'Male', '2013-03-15', 2, 'Primary', 'Joseph Kariuki', '0722111003', 'Active', '2023-01-09'),
('KK/PRI/2024/004', 'Mercy', 'Akinyi', 'Otieno', 'Female', '2012-11-04', 3, 'Primary', 'Lilian Otieno', '0722111004', 'Active', '2022-01-10'),
('KK/JUN/2024/001', 'Samuel', 'Njoroge', 'Kamau', 'Male', '2011-07-18', 4, 'Junior', 'Peter Kamau', '0722111005', 'Active', '2024-01-08'),
('KK/JUN/2024/002', 'Esther', 'Nekesa', 'Wafula', 'Female', '2011-09-25', 4, 'Junior', 'Moses Wafula', '0722111006', 'Active', '2024-01-08'),
('KK/JUN/2024/003', 'Victor', 'Mutiso', 'Musyoka', 'Male', '2010-04-02', 5, 'Junior', 'Agnes Musyoka', '0722111007', 'Active', '2023-01-09'),
('KK/JUN/2024/004', 'Joy', 'Wambui', 'Ndung\'u', 'Female', '2009-12-19', 6, 'Junior', 'Daniel Ndung\'u', '0722111008', 'Active', '2022-01-10');

-- Sample Assessments
INSERT INTO `assessments` (`name`, `type`, `division`, `academic_year`, `term`, `max_marks`, `is_published`) VALUES
('Term 1 Opening CAT', 'CAT', 'Both', '2026', 'Term 1', 50.00, 1),
('Term 1 Mid-Term Examination', 'Mid-Term', 'Both', '2026', 'Term 1', 100.00, 1),
('Term 1 End-Term Examination', 'End-Term', 'Both', '2026', 'Term 1', 100.00, 1);

-- Fee Structure 2026
INSERT INTO `fee_structures` (`division`, `class_id`, `academic_year`, `term`, `amount`, `description`) VALUES
('Primary', NULL, '2026', 'Term 1', 12500.00, 'Primary School Term 1 Tuition & Lunch Activity'),
('Junior', NULL, '2026', 'Term 1', 16500.00, 'Junior School Term 1 Tuition, Lab & Practical Materials');

-- Sample Fee Payments
INSERT INTO `fee_payments` (`receipt_no`, `student_id`, `amount_paid`, `payment_method`, `reference_no`, `payment_date`, `term`, `academic_year`, `received_by`, `notes`) VALUES
('REC-2026-001', 1, 10000.00, 'M-Pesa', 'QA12456789', '2026-01-10', 'Term 1', '2026', 1, 'Part payment for Term 1'),
('REC-2026-002', 5, 16500.00, 'Bank Deposit', 'BK98765432', '2026-01-12', 'Term 1', '2026', 1, 'Full payment for Term 1');

-- Sample Food / In-Kind Collections
INSERT INTO `food_collections` (`item_name`, `category`, `quantity`, `unit`, `contributed_by_student_id`, `contributor_name`, `status`, `collection_date`, `recorded_by`, `notes`) VALUES
('Dry Maize (90kg Bag)', 'Grain', 2.00, 'bags', 1, 'David Koech', 'In Stock', '2026-01-15', 1, 'Term 1 school feeding contribution'),
('Yellow Beans (90kg Bag)', 'Legume', 1.00, 'bags', 3, 'Joseph Kariuki', 'In Stock', '2026-01-16', 1, 'Lunches food supply');
