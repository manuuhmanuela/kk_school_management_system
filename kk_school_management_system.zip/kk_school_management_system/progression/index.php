<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher', 'Director of Studies']);

$pdo = get_db_connection();
$errors = [];

// Handle Progression POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['action_type'] ?? '';
    $student_id  = intval($_POST['student_id'] ?? 0);
    $to_class_id = !empty($_POST['to_class_id']) ? intval($_POST['to_class_id']) : null;
    $academic_yr = trim($_POST['academic_year'] ?? date('Y'));
    $remarks     = trim($_POST['remarks'] ?? '');

    // Get current student class
    $st_stmt = $pdo->prepare("SELECT current_class_id, division FROM students WHERE id = ?");
    $st_stmt->execute([$student_id]);
    $student = $st_stmt->fetch();

    if (!$student) {
        $errors[] = "Selected student record was not found.";
    }

    if (empty($errors)) {
        $from_class_id = $student['current_class_id'];
        $new_status = 'Active';
        $new_division = $student['division'];

        if ($action_type === 'Transfer_Out') {
            $new_status = 'Transferred';
            $to_class_id = $from_class_id;
        } elseif ($action_type === 'Graduation') {
            $new_status = 'Graduated';
            $to_class_id = $from_class_id;
        } elseif ($action_type === 'Primary_to_Junior') {
            $new_status = 'Promoted';
            $new_division = 'Junior';
        }

        // Record progression event
        $ins = $pdo->prepare("
            INSERT INTO student_progression (student_id, from_class_id, to_class_id, action_type, academic_year, remarks, recorded_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $ins->execute([
            $student_id, $from_class_id, $to_class_id, $action_type, 
            $academic_yr, $remarks, $_SESSION['user_id']
        ]);

        // Update student record
        $upd = $pdo->prepare("UPDATE students SET current_class_id = ?, division = ?, status = ? WHERE id = ?");
        $upd->execute([$to_class_id, $new_division, $new_status, $student_id]);

        log_audit('Student Progression', "Applied {$action_type} on student ID {$student_id}");
        set_flash('success', "Student progression successfully recorded!");
        redirect('progression/index.php');
    }
}

// Fetch all active students
$students = $pdo->query("SELECT s.id, s.admission_no, s.first_name, s.last_name, s.division, c.name as class_name FROM students s JOIN classes c ON s.current_class_id = c.id ORDER BY s.division ASC, c.id ASC, s.first_name ASC")->fetchAll();

// Fetch all classes
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();

// Fetch progression logs
$history = $pdo->query("
    SELECT p.*, s.admission_no, s.first_name, s.last_name, fc.name as from_c, tc.name as to_c, u.full_name as user_name 
    FROM student_progression p 
    JOIN students s ON p.student_id = s.id 
    JOIN classes fc ON p.from_class_id = fc.id 
    LEFT JOIN classes tc ON p.to_class_id = tc.id 
    LEFT JOIN users u ON p.recorded_by = u.id 
    ORDER BY p.id DESC LIMIT 50
")->fetchAll();

$page_title = 'Student Progression & Alumni';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Student Progression & Alumni Records</h3>
        <p class="text-muted mb-0">Manage end-of-year promotions, demotions, Primary-to-Junior transitions & transfers</p>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger shadow-sm">
        <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e): ?>
                <li><?= e($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Action Form -->
    <div class="col-lg-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold">
                <i class="bi bi-arrow-repeat me-1 text-primary"></i> Process Learner Progression
            </div>
            <div class="card-body p-3">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Action Type <span class="text-danger">*</span></label>
                        <select name="action_type" id="action_type" class="form-select" required onchange="handleActionChange()">
                            <option value="Promotion">Regular Class Promotion</option>
                            <option value="Primary_to_Junior">Primary to Junior Progression (Grade 6 -> Grade 7)</option>
                            <option value="Demotion">Class Demotion / Retention</option>
                            <option value="Transfer_Out">Transfer Out to Another School</option>
                            <option value="Graduation">Grade 9 Junior School Graduation (Alumni)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Select Learner <span class="text-danger">*</span></label>
                        <select name="student_id" class="form-select" required>
                            <option value="">-- Choose Learner --</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= $st['id'] ?>">
                                    <?= e($st['admission_no']) ?> &bull; <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['class_name']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3" id="to_class_wrapper">
                        <label class="form-label small fw-semibold">Promote / Move To Class <span class="text-danger">*</span></label>
                        <select name="to_class_id" id="to_class_id" class="form-select">
                            <option value="">-- Destination Class --</option>
                            <optgroup label="Primary School">
                                <?php foreach ($classes as $c): if ($c['division'] === 'Primary'): ?>
                                    <option value="<?= $c['id'] ?>"><?= e($c['name']) ?> (<?= e($c['stream']) ?>)</option>
                                <?php endif; endforeach; ?>
                            </optgroup>
                            <optgroup label="Junior School">
                                <?php foreach ($classes as $c): if ($c['division'] === 'Junior'): ?>
                                    <option value="<?= $c['id'] ?>"><?= e($c['name']) ?> (<?= e($c['stream']) ?>)</option>
                                <?php endif; endforeach; ?>
                            </optgroup>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Academic Year</label>
                        <input type="text" name="academic_year" class="form-control" value="2026" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold">Remarks / Reason</label>
                        <textarea name="remarks" class="form-control" rows="2" placeholder="e.g. Cleared academic benchmarks for promotion."></textarea>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary fw-semibold">
                            <i class="bi bi-check2-circle me-1"></i> Apply Progression Action
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Progression History Column -->
    <div class="col-lg-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold d-flex justify-content-between align-items-center">
                <span><i class="bi bi-clock-history me-1 text-primary"></i> Historical Progression & Transfer Log</span>
                <span class="badge bg-light text-dark border"><?= count($history) ?> records</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Learner</th>
                                <th>Action</th>
                                <th>Movement</th>
                                <th>Year</th>
                                <th>Remarks</th>
                                <th>Recorded By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($history)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5 text-muted">No progression movements recorded yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($history as $h): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?= e($h['first_name'] . ' ' . $h['last_name']) ?></div>
                                            <small class="text-muted"><?= e($h['admission_no']) ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-info text-dark"><?= e($h['action_type']) ?></span>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?= e($h['from_c']) ?></small> 
                                            <i class="bi bi-arrow-right text-secondary mx-1"></i> 
                                            <strong class="text-dark"><?= e($h['to_c'] ?? 'N/A') ?></strong>
                                        </td>
                                        <td><?= e($h['academic_year']) ?></td>
                                        <td><small><?= e($h['remarks']) ?></small></td>
                                        <td class="small text-muted"><?= e($h['user_name'] ?? 'System') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function handleActionChange() {
    const act = document.getElementById('action_type').value;
    const wrap = document.getElementById('to_class_wrapper');
    if (act === 'Transfer_Out' || act === 'Graduation') {
        wrap.style.display = 'none';
    } else {
        wrap.style.display = 'block';
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
