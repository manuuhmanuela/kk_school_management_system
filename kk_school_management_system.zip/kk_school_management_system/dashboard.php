<?php
require_once __DIR__ . '/config/init.php';
require_login();

$page_title = 'Dashboard';
$pdo = get_db_connection();
$division = get_active_division();

// Fetch summary metrics based on selected division
$div_condition = ($division !== 'All') ? " WHERE s.division = '{$division}'" : "";
$div_condition_and = ($division !== 'All') ? " AND s.division = '{$division}'" : "";

// Count students
$total_students = $pdo->query("SELECT COUNT(*) FROM students s $div_condition")->fetchColumn();
$active_students = $pdo->query("SELECT COUNT(*) FROM students s WHERE s.status = 'Active' $div_condition_and")->fetchColumn();

// Count teachers
$total_teachers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'Teacher' AND status = 'Active'")->fetchColumn();

// Count assessments
$total_assessments = $pdo->query("SELECT COUNT(*) FROM assessments")->fetchColumn();

// Total fees collected
$total_fees_collected = $pdo->query("SELECT COALESCE(SUM(amount_paid), 0) FROM fee_payments")->fetchColumn();

// Food items in stock
$total_food_stock = $pdo->query("SELECT COUNT(*) FROM food_collections WHERE status = 'In Stock'")->fetchColumn();

// Recent students
$students_stmt = $pdo->query("SELECT s.*, c.name as class_name FROM students s LEFT JOIN classes c ON s.current_class_id = c.id $div_condition ORDER BY s.id DESC LIMIT 5");
$recent_students = $students_stmt->fetchAll();

// Recent fee payments
$payments_stmt = $pdo->query("SELECT p.*, s.first_name, s.last_name, s.admission_no FROM fee_payments p JOIN students s ON p.student_id = s.id ORDER BY p.id DESC LIMIT 5");
$recent_payments = $payments_stmt->fetchAll();

// Require header partial (All redirects and processing completed above!)
require_once __DIR__ . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Academic & Management Dashboard</h3>
        <p class="text-muted mb-0">Overview of 
            <?php if ($division === 'Primary'): ?>
                <strong class="text-primary"><?= PRIMARY_SCHOOL_NAME ?></strong> (Grades 4, 5, 6)
            <?php elseif ($division === 'Junior'): ?>
                <strong class="text-warning"><?= JUNIOR_SCHOOL_NAME ?></strong> (Grades 7, 8, 9)
            <?php else: ?>
                <strong>Integrated Primary & Junior Schools</strong>
            <?php endif; ?>
        </p>
    </div>
    <div>
        <a href="<?= BASE_URL ?>students/create.php" class="btn btn-primary btn-sm shadow-sm">
            <i class="bi bi-person-plus-fill me-1"></i> Register Student
        </a>
        <a href="<?= BASE_URL ?>assessments/entry.php" class="btn btn-outline-secondary btn-sm shadow-sm ms-1">
            <i class="bi bi-pencil me-1"></i> Enter Marks
        </a>
    </div>
</div>

<!-- Key Performance Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small fw-semibold text-uppercase">Enrolled Learners</span>
                <h3 class="fw-bold text-dark mt-1 mb-0"><?= number_format($total_students) ?></h3>
                <small class="text-success"><i class="bi bi-check-circle"></i> <?= $active_students ?> Active Status</small>
            </div>
            <div class="icon-box bg-primary-subtle text-primary">
                <i class="bi bi-people-fill"></i>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small fw-semibold text-uppercase">Teaching Staff</span>
                <h3 class="fw-bold text-dark mt-1 mb-0"><?= number_format($total_teachers) ?></h3>
                <small class="text-muted">Allocated Across Grades</small>
            </div>
            <div class="icon-box bg-success-subtle text-success">
                <i class="bi bi-person-badge-fill"></i>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small fw-semibold text-uppercase">Total Fees Paid</span>
                <h3 class="fw-bold text-dark mt-1 mb-0">KES <?= number_format($total_fees_collected, 2) ?></h3>
                <small class="text-muted">Current Academic Year</small>
            </div>
            <div class="icon-box bg-warning-subtle text-warning">
                <i class="bi bi-cash-stack"></i>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small fw-semibold text-uppercase">Food / In-Kind Stock</span>
                <h3 class="fw-bold text-dark mt-1 mb-0"><?= number_format($total_food_stock) ?> Batches</h3>
                <small class="text-info">Feeding Program Stock</small>
            </div>
            <div class="icon-box bg-info-subtle text-info">
                <i class="bi bi-box-seam-fill"></i>
            </div>
        </div>
    </div>
</div>

<!-- Quick Navigation Quick Action Grid -->
<div class="row g-3 mb-4">
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-body p-3">
                <div class="d-flex flex-wrap gap-2 align-items-center">
                    <span class="fw-semibold me-2 text-secondary"><i class="bi bi-lightning-charge-fill text-warning"></i> Quick Operations:</span>
                    <a href="<?= BASE_URL ?>students/index.php" class="btn btn-sm btn-light border"><i class="bi bi-search me-1"></i> Student Search</a>
                    <a href="<?= BASE_URL ?>analysis/index.php" class="btn btn-sm btn-light border"><i class="bi bi-trophy-fill text-warning me-1"></i> Academic Rankings</a>
                    <a href="<?= BASE_URL ?>reports/index.php" class="btn btn-sm btn-light border"><i class="bi bi-printer-fill me-1"></i> Print Report Cards</a>
                    <a href="<?= BASE_URL ?>fees/pay.php" class="btn btn-sm btn-light border"><i class="bi bi-receipt me-1"></i> Record Fee Payment</a>
                    <a href="<?= BASE_URL ?>fees/food_collection.php" class="btn btn-sm btn-light border"><i class="bi bi-basket me-1"></i> Food Collection</a>
                    <a href="<?= BASE_URL ?>attendance/mark.php" class="btn btn-sm btn-light border"><i class="bi bi-check2-square me-1"></i> Daily Attendance</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Records Lists -->
<div class="row g-4">
    <!-- Recent Students Registered -->
    <div class="col-lg-7">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h6 class="mb-0 fw-bold text-dark"><i class="bi bi-people me-2 text-primary"></i>Recently Enrolled Learners</h6>
                <a href="<?= BASE_URL ?>students/index.php" class="btn btn-sm btn-link text-decoration-none">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Admission No</th>
                                <th>Student Name</th>
                                <th>Division & Class</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_students)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">No students recorded in this division yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_students as $st): ?>
                                    <tr>
                                        <td class="fw-semibold text-primary"><?= e($st['admission_no']) ?></td>
                                        <td><?= e($st['first_name'] . ' ' . $st['last_name']) ?></td>
                                        <td>
                                            <span class="badge <?= ($st['division'] === 'Primary') ? 'bg-primary-subtle text-primary' : 'bg-warning-subtle text-warning-emphasis' ?>">
                                                <?= e($st['division']) ?>
                                            </span>
                                            <?= e($st['class_name']) ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-success"><?= e($st['status']) ?></span>
                                        </td>
                                        <td class="text-end">
                                            <a href="<?= BASE_URL ?>students/view.php?id=<?= $st['id'] ?>" class="btn btn-sm btn-outline-secondary py-0 px-2" title="View Profile">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Fee Collections -->
    <div class="col-lg-5">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h6 class="mb-0 fw-bold text-dark"><i class="bi bi-receipt me-2 text-success"></i>Recent Fee Payments</h6>
                <a href="<?= BASE_URL ?>fees/index.php" class="btn btn-sm btn-link text-decoration-none">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Receipt</th>
                                <th>Learner</th>
                                <th>Amount</th>
                                <th class="text-end">Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_payments)): ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">No fee payments recorded yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_payments as $pay): ?>
                                    <tr>
                                        <td class="fw-bold small"><?= e($pay['receipt_no']) ?></td>
                                        <td>
                                            <div class="small fw-semibold"><?= e($pay['first_name'] . ' ' . $pay['last_name']) ?></div>
                                            <small class="text-muted"><?= e($pay['admission_no']) ?></small>
                                        </td>
                                        <td class="fw-semibold text-success">KES <?= number_format($pay['amount_paid'], 2) ?></td>
                                        <td class="text-end">
                                            <a href="<?= BASE_URL ?>fees/receipt.php?id=<?= $pay['id'] ?>" class="btn btn-sm btn-light border py-0 px-2" target="_blank" title="Print Receipt">
                                                <i class="bi bi-printer"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// Cleanly require footer layout
require_once __DIR__ . '/includes/footer.php'; 
?>
