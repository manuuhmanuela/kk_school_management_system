<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$division = get_active_division();

$assessment_id = intval($_GET['assessment_id'] ?? 0);
$class_id      = intval($_GET['class_id'] ?? 0);

// Fetch assessments
$assessments = $pdo->query("SELECT id, name, term, academic_year FROM assessments ORDER BY id DESC")->fetchAll();
if (!$assessment_id && !empty($assessments)) {
    $assessment_id = $assessments[0]['id'];
}

// Fetch classes
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();
if (!$class_id && !empty($classes)) {
    $class_id = $classes[0]['id'];
}

// Fetch students
$students_stmt = $pdo->prepare("SELECT s.*, c.name as class_name, c.stream FROM students s JOIN classes c ON s.current_class_id = c.id WHERE s.current_class_id = ? AND s.status = 'Active' ORDER BY s.first_name ASC");
$students_stmt->execute([$class_id]);
$students = $students_stmt->fetchAll();

$page_title = 'Report Cards Generator';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Report Cards Generator</h3>
        <p class="text-muted mb-0">Generate print-ready terminal progress reports with subject summaries and comments</p>
    </div>
    <div>
        <a href="<?= BASE_URL ?>analysis/index.php?assessment_id=<?= $assessment_id ?>&class_id=<?= $class_id ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-bar-chart me-1"></i> View Class Analysis
        </a>
    </div>
</div>

<!-- Selector Card -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Target Assessment Term</label>
                <select name="assessment_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($assessments as $a): ?>
                        <option value="<?= $a['id'] ?>" <?= ($assessment_id == $a['id']) ? 'selected' : '' ?>>
                            <?= e($a['name']) ?> (<?= e($a['term']) ?> <?= e($a['academic_year']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Target Class / Grade</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($class_id == $c['id']) ? 'selected' : '' ?>>
                            [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Load Class</button>
            </div>
        </form>
    </div>
</div>

<!-- Learners Report List -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold text-dark">
            <i class="bi bi-files me-2 text-primary"></i>Learner Report Cards (<?= count($students) ?> learners)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Admission No</th>
                        <th>Learner Full Name</th>
                        <th>Division & Grade</th>
                        <th>Status</th>
                        <th class="text-end">Print Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">No learners found in the selected class.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($students as $st): ?>
                            <tr>
                                <td class="fw-bold text-primary"><?= e($st['admission_no']) ?></td>
                                <td class="fw-semibold"><?= e($st['first_name'] . ' ' . $st['last_name']) ?></td>
                                <td>
                                    <span class="badge <?= ($st['division'] === 'Primary') ? 'bg-primary' : 'bg-warning text-dark' ?>">
                                        <?= e($st['division']) ?>
                                    </span>
                                    <?= e($st['class_name']) ?>
                                </td>
                                <td><span class="badge bg-success"><?= e($st['status']) ?></span></td>
                                <td class="text-end">
                                    <a href="<?= BASE_URL ?>reports/print_card.php?student_id=<?= $st['id'] ?>&assessment_id=<?= $assessment_id ?>" target="_blank" class="btn btn-sm btn-primary shadow-sm">
                                        <i class="bi bi-printer me-1"></i> Generate & Print Report Card
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
