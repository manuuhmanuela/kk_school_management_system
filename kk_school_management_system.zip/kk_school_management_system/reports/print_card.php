<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$student_id    = intval($_GET['student_id'] ?? 0);
$assessment_id = intval($_GET['assessment_id'] ?? 0);
$pdo = get_db_connection();

// Fetch student
$st_stmt = $pdo->prepare("SELECT s.*, c.name as class_name, c.stream FROM students s JOIN classes c ON s.current_class_id = c.id WHERE s.id = ?");
$st_stmt->execute([$student_id]);
$student = $st_stmt->fetch();

if (!$student) {
    die("Student not found.");
}

// Fetch assessment
if (!$assessment_id) {
    $a_stmt = $pdo->query("SELECT id FROM assessments ORDER BY id DESC LIMIT 1");
    $assessment_id = $a_stmt->fetchColumn();
}

$assess_stmt = $pdo->prepare("SELECT * FROM assessments WHERE id = ?");
$assess_stmt->execute([$assessment_id]);
$assessment = $assess_stmt->fetch();

// Fetch marks for this student and assessment
$marks_stmt = $pdo->prepare("
    SELECT m.score, m.is_absent, m.teacher_comment, sub.subject_name, sub.subject_code 
    FROM marks m 
    JOIN subjects sub ON m.subject_id = sub.id 
    WHERE m.assessment_id = ? AND m.student_id = ? 
    ORDER BY sub.subject_name ASC
");
$marks_stmt->execute([$assessment_id, $student_id]);
$scores = $marks_stmt->fetchAll();

// Calculate totals, averages, and remarks
$total_marks = 0;
$count_subjects = 0;
foreach ($scores as $s) {
    if (!$s['is_absent'] && $s['score'] !== null) {
        $total_marks += floatval($s['score']);
        $count_subjects++;
    }
}
$average_marks = ($count_subjects > 0) ? round($total_marks / $count_subjects, 1) : 0;

// Grade / Performance level function
function get_performance_level($score) {
    if ($score >= 80) return ['EE', 'Exceeding Expectations', 'text-success'];
    if ($score >= 65) return ['ME', 'Meeting Expectations', 'text-primary'];
    if ($score >= 50) return ['AE', 'Approaching Expectations', 'text-warning'];
    return ['BE', 'Below Expectations', 'text-danger'];
}

$school_header = ($student['division'] === 'Primary') ? PRIMARY_SCHOOL_NAME : JUNIOR_SCHOOL_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Card - <?= e($student['admission_no']) ?> - <?= e($student['first_name'] . ' ' . $student['last_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background-color: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #1e293b;
        }
        .report-card-container {
            max-width: 850px;
            margin: 30px auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border: 2px solid #0f172a;
        }
        .school-title {
            font-size: 1.5rem;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: 0.5px;
        }
        .table-scores th {
            background-color: #f1f5f9;
            color: #0f172a;
            font-weight: 700;
            border: 1px solid #cbd5e1;
        }
        .table-scores td {
            border: 1px solid #cbd5e1;
            padding: 8px;
        }
        @media print {
            body { background: #fff !important; }
            .report-card-container {
                box-shadow: none !important;
                border: 2px solid #000 !important;
                margin: 0 !important;
                max-width: 100% !important;
                padding: 20px !important;
            }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>

<div class="container no-print text-center my-3">
    <button onclick="window.print()" class="btn btn-primary px-4 shadow-sm">
        <i class="bi bi-printer me-1"></i> Print / Save as PDF
    </button>
    <button onclick="window.close()" class="btn btn-outline-secondary px-3 ms-2">
        Close Window
    </button>
</div>

<div class="report-card-container">
    <!-- Header -->
    <div class="text-center border-bottom pb-3 mb-4">
        <div class="school-title"><?= e($school_header) ?></div>
        <div class="text-muted fw-semibold">P.O. BOX 100 &bull; KOMBE, KENYA &bull; TEL: +254 711 000 111</div>
        <div class="badge bg-dark fs-6 mt-2 px-3 py-2">
            OFFICIAL LEARNER TERMINAL PROGRESS REPORT &bull; <?= strtoupper(e($assessment['term'] ?? 'TERM 1')) ?> <?= e($assessment['academic_year'] ?? '2026') ?>
        </div>
    </div>

    <!-- Student Bio Grid -->
    <div class="row g-2 mb-4 p-3 bg-light rounded border">
        <div class="col-6">
            <span class="text-muted small">Learner's Full Name:</span><br>
            <strong class="fs-6"><?= e($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['last_name']) ?></strong>
        </div>
        <div class="col-3">
            <span class="text-muted small">Admission No:</span><br>
            <strong class="text-primary fs-6"><?= e($student['admission_no']) ?></strong>
        </div>
        <div class="col-3">
            <span class="text-muted small">Gender:</span><br>
            <strong><?= e($student['gender']) ?></strong>
        </div>

        <div class="col-6">
            <span class="text-muted small">Division & Grade:</span><br>
            <strong><?= e($student['division']) ?> School &mdash; <?= e($student['class_name']) ?> (Stream: <?= e($student['stream']) ?>)</strong>
        </div>
        <div class="col-3">
            <span class="text-muted small">Assessment:</span><br>
            <strong><?= e($assessment['name'] ?? 'N/A') ?></strong>
        </div>
        <div class="col-3">
            <span class="text-muted small">Academic Year:</span><br>
            <strong><?= e($assessment['academic_year'] ?? '2026') ?></strong>
        </div>
    </div>

    <!-- Subject Marks Breakdown -->
    <h6 class="fw-bold text-dark text-uppercase mb-2"><i class="bi bi-card-checklist me-1"></i> Academic Competency & Performance Evaluation</h6>
    <table class="table table-scores align-middle mb-4">
        <thead>
            <tr>
                <th style="width: 50px;">#</th>
                <th>Subject Name</th>
                <th style="width: 120px;" class="text-center">Score (100%)</th>
                <th style="width: 160px;" class="text-center">Competency Level</th>
                <th>Teacher's Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($scores)): ?>
                <tr>
                    <td colspan="5" class="text-center py-4 text-muted">No marks recorded for this assessment.</td>
                </tr>
            <?php else: ?>
                <?php 
                $i = 1;
                foreach ($scores as $sc): 
                    $level = (!$sc['is_absent'] && $sc['score'] !== null) ? get_performance_level($sc['score']) : ['X', 'Absent', 'text-danger'];
                ?>
                    <tr>
                        <td class="text-center"><?= $i++ ?></td>
                        <td class="fw-semibold"><?= e($sc['subject_name']) ?> (<?= e($sc['subject_code']) ?>)</td>
                        <td class="text-center fw-bold">
                            <?= $sc['is_absent'] ? '<span class="text-danger">ABS</span>' : number_format($sc['score'], 0) ?>
                        </td>
                        <td class="text-center fw-bold <?= $level[2] ?>">
                            <?= $level[0] ?> &mdash; <?= $level[1] ?>
                        </td>
                        <td class="small"><?= e($sc['teacher_comment'] ?: 'Satisfactory progress demonstrated.') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Performance Summary Box -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="border rounded p-3 text-center bg-light">
                <span class="text-muted small text-uppercase">Total Marks</span>
                <h4 class="fw-bold mb-0 text-dark"><?= number_format($total_marks, 0) ?> / <?= $count_subjects * 100 ?></h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="border rounded p-3 text-center bg-light">
                <span class="text-muted small text-uppercase">Mean Average Score</span>
                <h4 class="fw-bold mb-0 text-primary"><?= $average_marks ?>%</h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="border rounded p-3 text-center bg-light">
                <span class="text-muted small text-uppercase">Overall Grading</span>
                <h5 class="fw-bold mb-0 text-success"><?= get_performance_level($average_marks)[1] ?></h5>
            </div>
        </div>
    </div>

    <!-- Official Comments & Signatures -->
    <div class="border p-3 rounded mb-4">
        <div class="mb-3">
            <span class="fw-bold text-dark small text-uppercase">Class Teacher's General Remarks:</span>
            <p class="mb-0 text-muted fst-italic">
                <?= ($average_marks >= 70) ? "Demonstrates exemplary mastery across foundational areas. Encouraged to maintain this commendable standard." : "Shows consistent effort. More dedicated revision recommended in core numerical and literacy areas." ?>
            </p>
        </div>
        <div>
            <span class="fw-bold text-dark small text-uppercase">Head Teacher's Endorsement & Signature:</span>
            <div class="d-flex justify-content-between align-items-end mt-3">
                <div>
                    <div style="border-bottom: 1px dotted #000; width: 220px; height: 30px;"></div>
                    <small class="text-muted">Signature & Official Stamp</small>
                </div>
                <div>
                    <span class="small fw-semibold">Next Term Resumption Date:</span> <strong>05th May 2026</strong>
                </div>
            </div>
        </div>
    </div>

    <!-- Grading Scale Key -->
    <div class="p-2 border rounded bg-light text-center small text-muted">
        <strong>Grading Key:</strong> 
        EE (80–100%): Exceeding Expectations &bull; 
        ME (65–79%): Meeting Expectations &bull; 
        AE (50–64%): Approaching Expectations &bull; 
        BE (Below 50%): Below Expectations
    </div>
</div>

</body>
</html>
