<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$division = get_active_division();

// Fetch assessments
$assess_query = "SELECT * FROM assessments WHERE 1=1";
if ($division !== 'All') {
    $assess_query .= " AND (division = 'Both' OR division = '{$division}')";
}
$assess_query .= " ORDER BY academic_year DESC, id DESC";
$assessments = $pdo->query($assess_query)->fetchAll();

$page_title = 'Assessments & Examinations';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Assessments & Marks Management</h3>
        <p class="text-muted mb-0">Weekly tests, Continuous Assessment Tests (CATs), Mid-Terms & Mock Examinations</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>assessments/entry.php" class="btn btn-primary btn-sm shadow-sm">
            <i class="bi bi-pencil-square me-1"></i> Enter / Edit Marks
        </a>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold"><i class="bi bi-journal-check me-2 text-primary"></i>Assessment Schedule & Publication Status</h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Assessment Name</th>
                        <th>Type</th>
                        <th>Division</th>
                        <th>Academic Term & Year</th>
                        <th>Max Marks</th>
                        <th>Publication Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($assessments)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">No assessments configured for this division.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($assessments as $a): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?= e($a['name']) ?></div>
                                </td>
                                <td><span class="badge bg-secondary-subtle text-secondary border"><?= e($a['type']) ?></span></td>
                                <td>
                                    <span class="badge <?= ($a['division'] === 'Primary') ? 'bg-primary' : (($a['division'] === 'Junior') ? 'bg-warning text-dark' : 'bg-info text-dark') ?>">
                                        <?= e($a['division']) ?>
                                    </span>
                                </td>
                                <td><?= e($a['term']) ?> &bull; <?= e($a['academic_year']) ?></td>
                                <td><strong><?= number_format($a['max_marks'], 0) ?></strong> pts</td>
                                <td>
                                    <?php if ($a['is_published']): ?>
                                        <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i> Published</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><i class="bi bi-lock me-1"></i> Draft / Unpublished</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?= BASE_URL ?>assessments/entry.php?assessment_id=<?= $a['id'] ?>" class="btn btn-outline-primary" title="Enter Marks">
                                            <i class="bi bi-pencil"></i> Marks
                                        </a>
                                        <a href="<?= BASE_URL ?>analysis/index.php?assessment_id=<?= $a['id'] ?>" class="btn btn-outline-info" title="View Analysis">
                                            <i class="bi bi-bar-chart"></i> Analysis
                                        </a>
                                        <a href="<?= BASE_URL ?>reports/index.php?assessment_id=<?= $a['id'] ?>" class="btn btn-outline-success" title="Generate Report Cards">
                                            <i class="bi bi-file-earmark-pdf"></i> Reports
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
