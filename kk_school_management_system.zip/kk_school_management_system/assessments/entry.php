<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$pdo = get_db_connection();
$division = get_active_division();

$assessment_id = intval($_GET['assessment_id'] ?? 0);
$class_id      = intval($_GET['class_id'] ?? 0);
$subject_id    = intval($_GET['subject_id'] ?? 0);

// Fetch assessments list
$assessments = $pdo->query("SELECT id, name, term, academic_year, division, max_marks FROM assessments ORDER BY id DESC")->fetchAll();

// If no assessment selected, pick the latest
if (!$assessment_id && !empty($assessments)) {
    $assessment_id = $assessments[0]['id'];
}

// Fetch classes
$classes = $pdo->query("SELECT id, name, division, stream FROM classes ORDER BY division ASC, id ASC")->fetchAll();
if (!$class_id && !empty($classes)) {
    $class_id = $classes[0]['id'];
}

// Determine division of selected class
$curr_class = null;
foreach ($classes as $c) {
    if ($c['id'] == $class_id) {
        $curr_class = $c;
        break;
    }
}

// Fetch subjects matching selected class division
$class_div = $curr_class['division'] ?? 'Primary';
$subj_stmt = $pdo->prepare("SELECT id, subject_name, subject_code FROM subjects WHERE division = ? OR division = 'Both' ORDER BY subject_name ASC");
$subj_stmt->execute([$class_div]);
$subjects = $subj_stmt->fetchAll();

if (!$subject_id && !empty($subjects)) {
    $subject_id = $subjects[0]['id'];
}

// Handle Marks POST Submission BEFORE HTML output
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marks'])) {
    $scores = $_POST['scores'] ?? [];
    $absent = $_POST['absent'] ?? [];
    $comments = $_POST['comments'] ?? [];

    $insert_stmt = $pdo->prepare("
        INSERT INTO marks (assessment_id, student_id, class_id, subject_id, score, is_absent, teacher_comment)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            score = VALUES(score),
            is_absent = VALUES(is_absent),
            teacher_comment = VALUES(teacher_comment)
    ");

    $count = 0;
    foreach ($scores as $student_id => $val) {
        $st_id = intval($student_id);
        $is_ab = isset($absent[$st_id]) ? 1 : 0;
        $score = ($is_ab || $val === '') ? null : floatval($val);
        $cmt = trim($comments[$st_id] ?? '');

        $insert_stmt->execute([
            $assessment_id,
            $st_id,
            $class_id,
            $subject_id,
            $score,
            $is_ab,
            $cmt
        ]);
        $count++;
    }

    log_audit('Marks Entered', "Saved marks for Assessment {$assessment_id}, Class {$class_id}, Subject {$subject_id}");
    set_flash('success', "Marks successfully recorded for {$count} learners!");
    redirect("assessments/entry.php?assessment_id={$assessment_id}&class_id={$class_id}&subject_id={$subject_id}");
}

// Fetch students in this class
$students_stmt = $pdo->prepare("SELECT id, admission_no, first_name, last_name FROM students WHERE current_class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$students_stmt->execute([$class_id]);
$students = $students_stmt->fetchAll();

// Fetch existing marks for this combo
$existing_marks = [];
if ($assessment_id && $class_id && $subject_id) {
    $marks_stmt = $pdo->prepare("SELECT student_id, score, is_absent, teacher_comment FROM marks WHERE assessment_id = ? AND class_id = ? AND subject_id = ?");
    $marks_stmt->execute([$assessment_id, $class_id, $subject_id]);
    while ($row = $marks_stmt->fetch()) {
        $existing_marks[$row['student_id']] = $row;
    }
}

// Get max marks for the assessment
$max_marks = 100;
foreach ($assessments as $a) {
    if ($a['id'] == $assessment_id) {
        $max_marks = $a['max_marks'];
        break;
    }
}

$page_title = 'Marks Entry';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Marks Entry & Validation</h3>
        <p class="text-muted mb-0">Record exam marks with automatic non-sitter / absentee tracking</p>
    </div>
    <a href="<?= BASE_URL ?>assessments/index.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back to Assessments
    </a>
</div>

<!-- Selection Filter Bar -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label small fw-semibold text-secondary">1. Assessment Exam</label>
                <select name="assessment_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($assessments as $a): ?>
                        <option value="<?= $a['id'] ?>" <?= ($assessment_id == $a['id']) ? 'selected' : '' ?>>
                            <?= e($a['name']) ?> (<?= e($a['term']) ?> <?= e($a['academic_year']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label small fw-semibold text-secondary">2. Class / Grade</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($class_id == $c['id']) ? 'selected' : '' ?>>
                            [<?= e($c['division']) ?>] <?= e($c['name']) ?> (<?= e($c['stream']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label small fw-semibold text-secondary">3. Subject</label>
                <select name="subject_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($subjects as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= ($subject_id == $s['id']) ? 'selected' : '' ?>>
                            <?= e($s['subject_name']) ?> (<?= e($s['subject_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-1">
                <button type="submit" class="btn btn-primary btn-sm w-100">Load</button>
            </div>
        </form>
    </div>
</div>

<!-- Marks Entry Table -->
<form method="POST" action="">
    <input type="hidden" name="save_marks" value="1">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <div>
                <h6 class="mb-0 fw-bold text-dark">
                    <i class="bi bi-pencil me-2 text-primary"></i>Marks Sheet &bull; Max Marks: <span class="badge bg-primary"><?= number_format($max_marks, 0) ?></span>
                </h6>
                <small class="text-muted">Enter marks or check Absent for non-sitters</small>
            </div>
            <button type="submit" class="btn btn-success btn-sm px-4 fw-bold shadow-sm">
                <i class="bi bi-check2-all me-1"></i> Save All Marks
            </button>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th style="width: 180px;">Admission No</th>
                            <th>Student Name</th>
                            <th style="width: 150px;">Score (/ <?= number_format($max_marks, 0) ?>)</th>
                            <th style="width: 130px;" class="text-center">Absent / Non-sitter</th>
                            <th>Teacher's Comment / Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    No active learners enrolled in this class.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $idx = 1;
                            foreach ($students as $st): 
                                $m = $existing_marks[$st['id']] ?? null;
                                $score_val = ($m && $m['score'] !== null) ? $m['score'] : '';
                                $is_absent = ($m && $m['is_absent'] == 1);
                                $comment = $m['teacher_comment'] ?? '';
                            ?>
                                <tr>
                                    <td><?= $idx++ ?></td>
                                    <td class="fw-bold text-primary"><?= e($st['admission_no']) ?></td>
                                    <td class="fw-semibold"><?= e($st['first_name'] . ' ' . $st['last_name']) ?></td>
                                    <td>
                                        <input type="number" step="0.5" min="0" max="<?= $max_marks ?>" 
                                               name="scores[<?= $st['id'] ?>]" 
                                               id="score_<?= $st['id'] ?>"
                                               class="form-control form-control-sm score-input" 
                                               value="<?= e($score_val) ?>" 
                                               <?= $is_absent ? 'disabled' : '' ?>
                                               placeholder="0 - <?= $max_marks ?>">
                                    </td>
                                    <td class="text-center">
                                        <div class="form-check d-flex justify-content-center">
                                            <input class="form-check-input" type="checkbox" 
                                                   name="absent[<?= $st['id'] ?>]" 
                                                   value="1" 
                                                   id="absent_<?= $st['id'] ?>"
                                                   <?= $is_absent ? 'checked' : '' ?>
                                                   onchange="toggleAbsent(<?= $st['id'] ?>)">
                                        </div>
                                    </td>
                                    <td>
                                        <input type="text" name="comments[<?= $st['id'] ?>]" 
                                               class="form-control form-control-sm" 
                                               placeholder="e.g. Good mastery, Needs revision..." 
                                               value="<?= e($comment) ?>">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if (!empty($students)): ?>
            <div class="card-footer bg-light p-3 d-flex justify-content-between align-items-center">
                <span class="text-muted small">All changes are immediately reflected in Academic Analysis and Report Cards.</span>
                <button type="submit" class="btn btn-success px-4 fw-bold shadow-sm">
                    <i class="bi bi-check2-all me-1"></i> Save All Marks
                </button>
            </div>
        <?php endif; ?>
    </div>
</form>

<script>
function toggleAbsent(studentId) {
    const chk = document.getElementById('absent_' + studentId);
    const scoreInp = document.getElementById('score_' + studentId);
    if (chk.checked) {
        scoreInp.value = '';
        scoreInp.disabled = true;
    } else {
        scoreInp.disabled = false;
        scoreInp.focus();
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
