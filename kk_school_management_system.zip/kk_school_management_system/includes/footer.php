        </main>
        <!-- Footer Partial -->
        <footer class="py-3 bg-white border-top mt-auto d-print-none">
            <div class="container-fluid px-4 d-flex flex-column flex-sm-row justify-content-between align-items-center text-muted small">
                <div>
                    <strong><?= APP_NAME ?></strong> &copy; <?= date('Y') ?> &mdash; Integrated Primary & Junior Academic Platform
                </div>
                <div>
                    <span><?= PRIMARY_SCHOOL_NAME ?> &bull; <?= JUNIOR_SCHOOL_NAME ?></span>
                </div>
            </div>
        </footer>
    </div>
</div>

<!-- Bootstrap 5 Bundle JS with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Application JS -->
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
<?php
// Flush output buffer cleanly
if (ob_get_level()) {
    ob_end_flush();
}
?>
