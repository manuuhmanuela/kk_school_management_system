<?php
// Get current active division
$current_division = get_active_division();
$user_assigned_division = $logged_user['assigned_division'] ?? 'All';
?>
<!-- Top Navigation Bar -->
<nav class="top-navbar d-flex justify-content-between align-items-center d-print-none">
    <div class="d-flex align-items-center gap-3">
        <button class="btn btn-outline-secondary btn-sm" id="sidebarToggle" title="Toggle Sidebar">
            <i class="bi bi-list fs-5"></i>
        </button>

        <!-- Division Switcher: Only allowed if user has 'All' access (Admin, Owner, DOS) -->
        <?php if ($user_assigned_division === 'All'): ?>
            <div class="d-none d-md-flex align-items-center gap-2 bg-light p-1 rounded-pill border">
                <span class="text-muted ms-2 me-1 small fw-semibold"><i class="bi bi-diagram-3"></i> Division:</span>
                <a href="?division=All" class="division-pill all <?= ($current_division == 'All') ? 'active' : '' ?>">All Divisions</a>
                <a href="?division=Primary" class="division-pill primary <?= ($current_division == 'Primary') ? 'active' : '' ?>">
                    <i class="bi bi-backpack me-1"></i> Kombe Primary (Gr 4-6)
                </a>
                <a href="?division=Junior" class="division-pill junior <?= ($current_division == 'Junior') ? 'active' : '' ?>">
                    <i class="bi bi-book-half me-1"></i> Kombe Junior (Gr 7-9)
                </a>
            </div>
        <?php else: ?>
            <span class="badge bg-primary px-3 py-2 fs-6">
                <i class="bi bi-building me-1"></i> <?= ($user_assigned_division == 'Primary') ? PRIMARY_SCHOOL_NAME : JUNIOR_SCHOOL_NAME ?>
            </span>
        <?php endif; ?>
    </div>

    <!-- Right Profile / User Dropdown -->
    <div class="dropdown">
        <button class="btn btn-link text-dark dropdown-toggle text-decoration-none d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px; font-weight: bold;">
                <?= strtoupper(substr($logged_user['full_name'] ?? 'U', 0, 1)) ?>
            </div>
            <div class="text-start d-none d-sm-block">
                <div class="fw-semibold text-dark small lh-1"><?= e($logged_user['full_name'] ?? 'User') ?></div>
                <small class="text-muted" style="font-size: 0.75rem;"><?= e($logged_user['role'] ?? 'Role') ?></small>
            </div>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
            <li class="dropdown-header">
                <strong>Signed in as</strong><br>
                <span class="text-muted"><?= e($logged_user['email'] ?? '') ?></span>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <span class="dropdown-item-text small text-secondary">
                    Role: <strong class="text-dark"><?= e($logged_user['role'] ?? '') ?></strong>
                </span>
            </li>
            <li>
                <span class="dropdown-item-text small text-secondary">
                    Division: <strong class="text-dark"><?= e($logged_user['assigned_division'] ?? 'All') ?></strong>
                </span>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <a class="dropdown-item text-danger d-flex align-items-center gap-2" href="<?= BASE_URL ?>logout.php">
                    <i class="bi bi-box-arrow-right"></i> Sign Out
                </a>
            </li>
        </ul>
    </div>
</nav>
