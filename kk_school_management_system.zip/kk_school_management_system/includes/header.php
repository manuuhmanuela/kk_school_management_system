<?php
/**
 * Header partial for KK School Management System
 * Note: Session, buffer, and authentication must have been initialized prior to this file.
 */
$page_title = isset($page_title) ? $page_title . ' - ' . APP_NAME : APP_NAME;
$logged_user = get_logged_user();
$active_division = get_active_division();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($page_title) ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom Application CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="d-flex" id="wrapper">
    <!-- Sidebar Partial -->
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <!-- Page Content Wrapper -->
    <div id="page-content-wrapper" class="w-100 d-flex flex-column min-vh-100">
        <!-- Top Navigation Bar Partial -->
        <?php require_once __DIR__ . '/navbar.php'; ?>

        <!-- Main Content Area -->
        <main class="container-fluid px-4 py-4 flex-grow-1">
            <?php 
            $flash = get_flash();
            if ($flash): 
            ?>
                <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show shadow-sm" role="alert">
                    <i class="bi bi-info-circle-fill me-2"></i>
                    <?= e($flash['message']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
