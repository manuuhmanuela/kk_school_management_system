<?php
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
$role = $logged_user['role'] ?? 'Teacher';
?>
<!-- Sidebar -->
<div id="sidebar-wrapper" class="d-print-none">
    <div class="sidebar-heading d-flex align-items-center">
        <i class="bi bi-mortarboard-fill fs-3 text-warning me-2"></i>
        <div>
            <div class="fw-bold lh-1 text-white">KK SCHOOLS</div>
            <small class="text-secondary" style="font-size: 0.72rem;">Management System</small>
        </div>
    </div>
    
    <div class="list-group list-group-flush my-2">
        <a href="<?= BASE_URL ?>index.php" class="list-group-item text-info">
            <i class="bi bi-globe2"></i> Public Website
        </a>

        <a href="<?= BASE_URL ?>dashboard.php" class="list-group-item <?= ($current_page == 'dashboard.php') ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2-fill"></i> Dashboard
        </a>

        <!-- Student Management -->
        <a href="<?= BASE_URL ?>students/index.php" class="list-group-item <?= ($current_dir == 'students') ? 'active' : '' ?>">
            <i class="bi bi-people-fill"></i> Students
        </a>

        <!-- Teachers (Admin, Owner, Head, DOS) -->
        <?php if (in_array($role, ['Owner', 'Administrator', 'Head Teacher', 'Director of Studies'])): ?>
            <a href="<?= BASE_URL ?>teachers/index.php" class="list-group-item <?= ($current_dir == 'teachers') ? 'active' : '' ?>">
                <i class="bi bi-person-badge-fill"></i> Teachers & Allocation
            </a>
        <?php endif; ?>

        <!-- Assessments & Marks -->
        <a href="<?= BASE_URL ?>assessments/index.php" class="list-group-item <?= ($current_dir == 'assessments') ? 'active' : '' ?>">
            <i class="bi bi-pencil-square"></i> Assessments & Marks
        </a>

        <!-- Academic Analysis -->
        <a href="<?= BASE_URL ?>analysis/index.php" class="list-group-item <?= ($current_dir == 'analysis') ? 'active' : '' ?>">
            <i class="bi bi-bar-chart-fill"></i> Academic Analysis
        </a>

        <!-- Report Cards -->
        <a href="<?= BASE_URL ?>reports/index.php" class="list-group-item <?= ($current_dir == 'reports') ? 'active' : '' ?>">
            <i class="bi bi-file-earmark-text-fill"></i> Report Cards
        </a>

        <!-- Progression & Promotion -->
        <?php if (in_array($role, ['Owner', 'Administrator', 'Head Teacher', 'Director of Studies'])): ?>
            <a href="<?= BASE_URL ?>progression/index.php" class="list-group-item <?= ($current_dir == 'progression') ? 'active' : '' ?>">
                <i class="bi bi-arrow-up-right-circle-fill"></i> Progression & Alumni
            </a>
        <?php endif; ?>

        <!-- Fees & In-Kind / Food Collection -->
        <?php if (in_array($role, ['Owner', 'Administrator', 'Head Teacher'])): ?>
            <a href="<?= BASE_URL ?>fees/index.php" class="list-group-item <?= ($current_dir == 'fees') ? 'active' : '' ?>">
                <i class="bi bi-cash-stack"></i> School Fees & Stock
            </a>
        <?php endif; ?>

        <!-- Attendance -->
        <a href="<?= BASE_URL ?>attendance/index.php" class="list-group-item <?= ($current_dir == 'attendance') ? 'active' : '' ?>">
            <i class="bi bi-calendar-check-fill"></i> Attendance Register
        </a>

        <!-- System Administration & Audit -->
        <?php if (in_array($role, ['Owner', 'Administrator'])): ?>
            <a href="<?= BASE_URL ?>settings/audit.php" class="list-group-item <?= ($current_page == 'audit.php') ? 'active' : '' ?>">
                <i class="bi bi-shield-lock-fill"></i> System Audit Logs
            </a>
        <?php endif; ?>
    </div>

    <!-- Active Division Indicator Box -->
    <div class="px-3 py-3 mt-auto border-top border-secondary">
        <small class="text-uppercase text-secondary fw-bold" style="font-size:0.65rem;">Active Division</small>
        <div class="mt-1 d-flex align-items-center">
            <span class="badge <?= ($active_division == 'Primary') ? 'bg-primary' : (($active_division == 'Junior') ? 'bg-warning text-dark' : 'bg-secondary') ?> p-2 w-100 text-center">
                <?= ($active_division == 'Primary') ? 'Primary (Grades 4-6)' : (($active_division == 'Junior') ? 'Junior (Grades 7-9)' : 'All Divisions') ?>
            </span>
        </div>
    </div>
</div>
