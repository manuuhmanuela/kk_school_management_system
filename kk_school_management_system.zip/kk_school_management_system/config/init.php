<?php
/**
 * Application Initialization
 * IMPORTANT: ob_start() is called first to guarantee NO 'headers already sent' issues!
 * All session starts, error handlers, and authentication checks execute here.
 */
if (!ob_get_level()) {
    ob_start();
}

// Session security settings
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

// Global App Constants
define('APP_NAME', 'KK SCHOOL MANAGEMENT SYSTEM');
define('PRIMARY_SCHOOL_NAME', 'KOMBE AIC PRIMARY SCHOOL');
define('JUNIOR_SCHOOL_NAME', 'KOMBE AIC JUNIOR SCHOOL');
define('APP_VERSION', '1.0.0');

// Calculate BASE_URL dynamically
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$script_name = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
// Normalize base path for kk_school_management_system
$pos = strpos($script_name, '/kk_school_management_system');
if ($pos !== false) {
    $base_dir = substr($script_name, 0, $pos + strlen('/kk_school_management_system'));
} else {
    $base_dir = '/kk_school_management_system';
}
define('BASE_URL', rtrim($protocol . $host . $base_dir, '/') . '/');

// Include Database connection
require_once __DIR__ . '/database.php';

// Safe URL redirection helper to prevent header issues
function redirect($path) {
    if (ob_get_length()) {
        ob_clean(); // clean previous buffer before sending redirect header
    }
    if (strpos($path, 'http') === 0) {
        header("Location: " . $path);
    } else {
        header("Location: " . BASE_URL . ltrim($path, '/'));
    }
    exit;
}

// Flash Message Helpers
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// Authentication Helpers
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function get_logged_user() {
    return $_SESSION['user'] ?? null;
}

function is_student_logged_in() {
    return isset($_SESSION['student_id']) && !empty($_SESSION['student_id']);
}

function get_logged_student() {
    return $_SESSION['student'] ?? null;
}

function require_student_login() {
    if (!is_student_logged_in()) {
        set_flash('danger', 'Please enter your Admission Number and Surname to view your student portal.');
        redirect('student_login.php');
    }
}

function require_login() {
    if (!is_logged_in()) {
        set_flash('danger', 'You must log in to access this page.');
        redirect('login.php');
    }
}

function require_roles(array $roles) {
    require_login();
    $current_role = $_SESSION['user']['role'] ?? '';
    if (!in_array($current_role, $roles)) {
        set_flash('danger', 'Access denied. You do not have permission to view that section.');
        redirect('dashboard.php');
    }
}

// Active Division Filter (Primary vs Junior vs All)
function get_active_division() {
    // 1. URL parameter override
    if (isset($_GET['division']) && in_array($_GET['division'], ['Primary', 'Junior', 'All'])) {
        $_SESSION['active_division'] = $_GET['division'];
    }
    // 2. User assigned division constraint (if user is strictly Primary or Junior teacher)
    $user_division = $_SESSION['user']['assigned_division'] ?? 'All';
    if ($user_division !== 'All') {
        return $user_division;
    }
    return $_SESSION['active_division'] ?? 'All';
}

function set_active_division($division) {
    if (in_array($division, ['Primary', 'Junior', 'All'])) {
        $_SESSION['active_division'] = $division;
    }
}

// Sanitize output
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

// Audit Logger
function log_audit($action, $details = '') {
    try {
        $pdo = get_db_connection();
        $user_id = $_SESSION['user_id'] ?? null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $action, $details, $ip]);
    } catch (Exception $e) {
        // Silently catch to avoid crashing user flow if audit table is pending
    }
}

// Auto-run schema installer if tables are missing
function ensure_database_installed() {
    try {
        $pdo = get_db_connection();
        $check = $pdo->query("SHOW TABLES LIKE 'users'")->fetch();
        if (!$check) {
            $sql_file = __DIR__ . '/../database/kk_school_db.sql';
            if (!file_exists($sql_file)) {
                $sql_file = __DIR__ . '/../database/schema.sql';
            }
            if (file_exists($sql_file)) {
                $sql = file_get_contents($sql_file);
                $pdo->exec($sql);
            }
        }
    } catch (Exception $e) {
        // Handled gracefully
    }
}
ensure_database_installed();
