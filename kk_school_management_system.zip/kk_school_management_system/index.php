<?php
require_once __DIR__ . '/config/init.php';

// Handle contact form submission
$contact_feedback = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_contact'])) {
    $sender_name    = trim($_POST['name'] ?? '');
    $sender_email   = trim($_POST['email'] ?? '');
    $sender_phone   = trim($_POST['phone'] ?? '');
    $division_interest = trim($_POST['division_interest'] ?? 'General Inquiry');
    $message        = trim($_POST['message'] ?? '');

    if (!empty($sender_name) && (!empty($sender_email) || !empty($sender_phone)) && !empty($message)) {
        // Record as an audit/communication entry
        log_audit('Public Contact Inquiry', "From {$sender_name} ({$sender_phone} / {$sender_email}) for {$division_interest}: {$message}");
        $contact_feedback = [
            'type' => 'success',
            'msg'  => "Thank you, {$sender_name}! Your inquiry regarding {$division_interest} has been received. Our administration team will contact you shortly."
        ];
    } else {
        $contact_feedback = [
            'type' => 'danger',
            'msg'  => "Please fill in your name, contact phone or email, and inquiry message."
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> &mdash; Kombe AIC Primary & Junior Schools</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #ffffff;
            color: #334155;
            scroll-behavior: smooth;
        }

        /* Public Navigation Bar */
        .public-navbar {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        .public-navbar .nav-link {
            font-weight: 600;
            color: #334155;
            padding: 0.6rem 1rem;
            transition: color 0.2s;
        }
        .public-navbar .nav-link:hover {
            color: #1e3a8a;
        }

        /* Hero Section */
        .hero-section {
            background: radial-gradient(circle at top right, #1e3a8a 0%, #0f172a 100%);
            color: #ffffff;
            padding: 90px 0 100px;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: -20%;
            right: -10%;
            width: 500px;
            height: 500px;
            background: rgba(59, 130, 246, 0.15);
            border-radius: 50%;
            filter: blur(80px);
        }

        /* Section Titles */
        .section-tag {
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: #2563eb;
            background: #eff6ff;
            padding: 6px 14px;
            border-radius: 30px;
            display: inline-block;
        }
        .section-title {
            font-size: 2.25rem;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: -0.5px;
        }

        /* Feature & Service Cards */
        .service-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 30px;
            transition: transform 0.25s ease, box-shadow 0.25s ease;
            height: 100%;
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.08), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            border-color: #bfdbfe;
        }
        .service-icon-box {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            margin-bottom: 20px;
        }

        /* Division Showcase Box */
        .division-box {
            border-radius: 20px;
            padding: 35px;
            color: #ffffff;
            height: 100%;
            position: relative;
            overflow: hidden;
        }
        .division-box.primary {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
        }
        .division-box.junior {
            background: linear-gradient(135deg, #0f766e 0%, #0d9488 100%);
        }

        /* Contact Form Card */
        .contact-box {
            background: #ffffff;
            border-radius: 20px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            padding: 40px;
        }

        /* Footer */
        .landing-footer {
            background: #0f172a;
            color: #94a3b8;
            padding: 60px 0 25px;
        }
        .landing-footer h6 {
            color: #ffffff;
            font-weight: 700;
        }
        .landing-footer a {
            color: #94a3b8;
            text-decoration: none;
            transition: color 0.2s;
        }
        .landing-footer a:hover {
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Public Top Bar & Navigation -->
<nav class="navbar navbar-expand-lg public-navbar sticky-top">
    <div class="container py-1">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#hero">
            <div class="bg-primary text-white rounded-3 p-2 d-flex align-items-center justify-content-center shadow-sm" style="width: 42px; height: 42px;">
                <i class="bi bi-mortarboard-fill fs-5 text-warning"></i>
            </div>
            <div>
                <span class="fw-bold fs-5 text-dark lh-1 d-block">KK SCHOOLS</span>
                <small class="text-muted fw-semibold" style="font-size: 0.72rem;">Kombe AIC Primary & Junior</small>
            </div>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#publicNav" aria-controls="publicNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="publicNav">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="#hero">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#about">Who We Are</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#divisions">Our Divisions</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#services">Our Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contact">Contact Us</a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-2">
                <?php if (is_logged_in()): ?>
                    <a href="dashboard.php" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm">
                        <i class="bi bi-grid-1x2-fill me-1"></i> Go to Dashboard
                    </a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline-primary btn-sm px-3 fw-semibold">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Staff Login
                    </a>
                    <a href="#contact" class="btn btn-primary btn-sm px-3 fw-semibold shadow-sm">
                        Enroll Learner
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- 1. HERO SECTION -->
<header id="hero" class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7 text-center text-lg-start">
                <div class="badge bg-white text-primary px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
                    <i class="bi bi-award-fill text-warning me-1"></i> Nurturing Academic & Moral Excellence
                </div>
                <h1 class="display-4 fw-extrabold text-white lh-sm mb-4">
                    Integrated Primary and Junior School Management & Learning Platform
                </h1>
                <p class="lead text-light opacity-90 mb-4" style="max-width: 620px;">
                    Welcome to <strong>Kombe AIC Primary School</strong> (Grades 4–6) and <strong>Kombe AIC Junior School</strong> (Grades 7–9). Empowering learners with modern CBC curriculum, digital academic tracking, and transparent administration.
                </p>
                <div class="d-flex flex-wrap gap-3 justify-content-center justify-content-lg-start">
                    <a href="#about" class="btn btn-light btn-lg px-4 fw-bold text-primary shadow">
                        Learn Who We Are <i class="bi bi-arrow-down-short ms-1"></i>
                    </a>
                    <a href="login.php" class="btn btn-outline-light btn-lg px-4 fw-semibold">
                        <i class="bi bi-shield-lock me-1"></i> Access Portal
                    </a>
                </div>

                <!-- Stats Counters -->
                <div class="row g-3 mt-5 pt-3 border-top border-light border-opacity-25 text-start">
                    <div class="col-4">
                        <h3 class="fw-bold text-white mb-0">Grade 4–6</h3>
                        <small class="text-light opacity-75">Primary Division</small>
                    </div>
                    <div class="col-4">
                        <h3 class="fw-bold text-white mb-0">Grade 7–9</h3>
                        <small class="text-light opacity-75">Junior Division</small>
                    </div>
                    <div class="col-4">
                        <h3 class="fw-bold text-white mb-0">100%</h3>
                        <small class="text-light opacity-75">Digital Accuracy</small>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="bg-white rounded-4 p-4 shadow-lg text-dark">
                    <div class="d-flex align-items-center justify-content-between pb-3 border-bottom mb-3">
                        <div class="d-flex align-items-center gap-2">
                            <span class="p-2 bg-primary-subtle text-primary rounded-circle">
                                <i class="bi bi-calendar-event fs-5"></i>
                            </span>
                            <div>
                                <h6 class="fw-bold mb-0">Academic Term Portal</h6>
                                <small class="text-muted">Academic Year 2026</small>
                            </div>
                        </div>
                        <span class="badge bg-success">Active Session</span>
                    </div>

                    <div class="p-3 bg-light rounded-3 mb-3 border">
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Primary School (Grades 4–6)</span>
                            <span class="text-primary">Enrolling</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 85%"></div>
                        </div>
                    </div>

                    <div class="p-3 bg-light rounded-3 mb-3 border">
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Junior School (Grades 7–9)</span>
                            <span class="text-teal" style="color:#0d9488;">CBC Laboratories Ready</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 90%"></div>
                        </div>
                    </div>

                    <div class="d-grid mt-4">
                        <a href="login.php" class="btn btn-primary fw-bold py-2 shadow-sm">
                            <i class="bi bi-person-circle me-1"></i> Sign In to Portal
                        </a>
                        <small class="text-center text-muted mt-2">Teachers, Head Teachers & Administrators</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- 2. WHO WE ARE -->
<section id="about" class="py-5 my-4">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag">Who We Are</span>
            <h2 class="section-title mt-2">Dedicated to Holistic Education & Character Formation</h2>
            <p class="text-muted mx-auto" style="max-width: 650px;">
                Founded on firm Christian principles and holistic educational practices, Kombe AIC Primary and Junior Schools provide a nurturing, learner-centered environment.
            </p>
        </div>

        <div class="row g-4 align-items-center">
            <div class="col-lg-6">
                <div class="p-4 bg-light rounded-4 border">
                    <h4 class="fw-bold text-primary mb-3">Our Mission & Identity</h4>
                    <p class="text-secondary leading-relaxed">
                        At <strong>KOMBE AIC PRIMARY SCHOOL</strong> and <strong>KOMBE AIC JUNIOR SCHOOL</strong>, our mission is to develop competent, morally grounded, and innovative young minds equipped to thrive in Kenya's Competency-Based Curriculum (CBC) framework and global society.
                    </p>
                    <p class="text-secondary mb-4">
                        We transition learners seamlessly through Upper Primary (Grades 4, 5, 6) into Junior School (Grades 7, 8, 9), preserving complete historical academic records, assessment analytics, and pastoral growth without disruption.
                    </p>

                    <div class="row g-3">
                        <div class="col-sm-6">
                            <div class="d-flex align-items-start gap-2">
                                <i class="bi bi-check-circle-fill text-success fs-5"></i>
                                <div>
                                    <h6 class="fw-bold mb-0">Christian Foundations</h6>
                                    <small class="text-muted">Strong moral compass & spiritual guidance</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="d-flex align-items-start gap-2">
                                <i class="bi bi-check-circle-fill text-success fs-5"></i>
                                <div>
                                    <h6 class="fw-bold mb-0">CBC Excellence</h6>
                                    <small class="text-muted">Hands-on practical & STEM learning</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="d-flex align-items-start gap-2">
                                <i class="bi bi-check-circle-fill text-success fs-5"></i>
                                <div>
                                    <h6 class="fw-bold mb-0">Integrated Feeding</h6>
                                    <small class="text-muted">Nutritious hot meals & food stock control</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="d-flex align-items-start gap-2">
                                <i class="bi bi-check-circle-fill text-success fs-5"></i>
                                <div>
                                    <h6 class="fw-bold mb-0">Transparent Records</h6>
                                    <small class="text-muted">Real-time marks, fees, and report cards</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-12">
                        <div class="card border-0 shadow-sm p-4 bg-primary text-white rounded-4">
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <i class="bi bi-eye-fill fs-2 text-warning"></i>
                                <h5 class="fw-bold mb-0">Our Vision</h5>
                            </div>
                            <p class="mb-0 opacity-90">
                                To be a beacon of academic distinction, spiritual maturity, and holistic learner empowerment across both primary and junior secondary levels.
                            </p>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card border-0 shadow-sm p-4 bg-dark text-white rounded-4">
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <i class="bi bi-compass-fill fs-2 text-info"></i>
                                <h5 class="fw-bold mb-0">Core Values</h5>
                            </div>
                            <p class="mb-0 opacity-90">
                                Integrity &bull; Excellence &bull; Discipline &bull; Accountability &bull; Inclusivity &bull; Stewardship
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 3. OUR DIVISIONS -->
<section id="divisions" class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag">School Divisions</span>
            <h2 class="section-title mt-2">Two Distinct Divisions &bull; One Integrated Standard</h2>
            <p class="text-muted mx-auto" style="max-width: 650px;">
                Tailored educational environments designed to cater specifically to developmental and CBC curriculum requirements.
            </p>
        </div>

        <div class="row g-4">
            <!-- Kombe AIC Primary School -->
            <div class="col-lg-6">
                <div class="division-box primary">
                    <span class="badge bg-white text-primary fw-bold px-3 py-1 rounded-pill mb-3">Primary Division</span>
                    <h3 class="fw-bold mb-2">KOMBE AIC PRIMARY SCHOOL</h3>
                    <h6 class="text-light opacity-90 mb-3">Upper Primary: Grades 4, 5, and 6</h6>
                    <p class="opacity-90 mb-4">
                        Laying firm intellectual foundations with inquiry-based learning, foundational literacy and numeracy, basic scientific inquiry, and talent development.
                    </p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i> Mathematics, English & Kiswahili</li>
                        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i> Science & Technology & Agriculture</li>
                        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i> Social Studies, C.R.E & Creative Arts</li>
                        <li class="mb-0"><i class="bi bi-check2-circle me-2"></i> Continuous Assessment Tests & End-Term Evaluations</li>
                    </ul>
                    <a href="#contact" class="btn btn-light fw-bold text-primary px-4">Inquire for Primary Admission</a>
                </div>
            </div>

            <!-- Kombe AIC Junior School -->
            <div class="col-lg-6">
                <div class="division-box junior">
                    <span class="badge bg-white text-teal fw-bold px-3 py-1 rounded-pill mb-3" style="color:#0d9488;">Junior Division</span>
                    <h3 class="fw-bold mb-2">KOMBE AIC JUNIOR SCHOOL</h3>
                    <h6 class="text-light opacity-90 mb-3">Junior Secondary: Grades 7, 8, and 9</h6>
                    <p class="opacity-90 mb-4">
                        Deepening competencies through pre-technical studies, practical laboratories, business acumen, and preparing learners for senior secondary pathways.
                    </p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i> Integrated Science & Pre-Technical Studies</li>
                        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i> Mathematics, English, Kiswahili & Business Studies</li>
                        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i> Social Studies, Agriculture & Religious Education</li>
                        <li class="mb-0"><i class="bi bi-check2-circle me-2"></i> National Mock Exams, Career Pathway Mentorship & Graduation</li>
                    </ul>
                    <a href="#contact" class="btn btn-light fw-bold px-4" style="color:#0d9488;">Inquire for Junior Admission</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 4. OUR SERVICES -->
<section id="services" class="py-5 my-4">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag">Our Services</span>
            <h2 class="section-title mt-2">Comprehensive Academic & Administrative Services</h2>
            <p class="text-muted mx-auto" style="max-width: 650px;">
                Powered by our integrated digital school management system ensuring accountability, accurate reports, and prompt communication.
            </p>
        </div>

        <div class="row g-4">
            <!-- Service 1 -->
            <div class="col-md-6 col-lg-4">
                <div class="service-card">
                    <div class="service-icon-box bg-primary-subtle text-primary">
                        <i class="bi bi-person-lines-fill"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Student & Teacher Management</h5>
                    <p class="text-muted small mb-0">
                        Complete digital biodata, admission records, class allocation, subject teacher assignments, and permanent non-destructive archival.
                    </p>
                </div>
            </div>

            <!-- Service 2 -->
            <div class="col-md-6 col-lg-4">
                <div class="service-card">
                    <div class="service-icon-box bg-success-subtle text-success">
                        <i class="bi bi-journal-check"></i>
                    </div>
                    <h5 class="fw-bold mb-2">CBC Assessment & Examinations</h5>
                    <p class="text-muted small mb-0">
                        Weekly tests, Continuous Assessment Tests (CATs), Mid-Terms, and Mocks with automated competency level computation (EE, ME, AE, BE).
                    </p>
                </div>
            </div>

            <!-- Service 3 -->
            <div class="col-md-6 col-lg-4">
                <div class="service-card">
                    <div class="service-icon-box bg-warning-subtle text-warning">
                        <i class="bi bi-graph-up-arrow"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Academic Performance Analysis</h5>
                    <p class="text-muted small mb-0">
                        Class mean analysis, learner merit rankings, subject champions, improved and declining indicators, and non-sitter tracking.
                    </p>
                </div>
            </div>

            <!-- Service 4 -->
            <div class="col-md-6 col-lg-4">
                <div class="service-card">
                    <div class="service-icon-box bg-info-subtle text-info">
                        <i class="bi bi-printer-fill"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Terminal Report Cards</h5>
                    <p class="text-muted small mb-0">
                        Print-ready individual learner progress reports featuring subject summaries, teacher remarks, and official school leadership endorsements.
                    </p>
                </div>
            </div>

            <!-- Service 5 -->
            <div class="col-md-6 col-lg-4">
                <div class="service-card">
                    <div class="service-icon-box bg-danger-subtle text-danger">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                    <h5 class="fw-bold mb-2">School Fees & Receipting</h5>
                    <p class="text-muted small mb-0">
                        Transparent fee tracking with instant payment receipts (M-Pesa, Cash, Bank Deposit), balance summaries, and statements.
                    </p>
                </div>
            </div>

            <!-- Service 6 -->
            <div class="col-md-6 col-lg-4">
                <div class="service-card">
                    <div class="service-icon-box bg-secondary-subtle text-secondary">
                        <i class="bi bi-basket-fill"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Food Collection & Stock Control</h5>
                    <p class="text-muted small mb-0">
                        In-kind food contribution records (grains, legumes, produce) supporting the school lunch feeding program with granary stock control.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 5. CONTACT US -->
<section id="contact" class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag">Get In Touch</span>
            <h2 class="section-title mt-2">Contact School Administration</h2>
            <p class="text-muted mx-auto" style="max-width: 650px;">
                Have questions regarding learner enrollment, fee structures, or academic programs? Send us a message or visit our campus.
            </p>
        </div>

        <div class="row g-4 align-items-stretch">
            <!-- Contact Information Column -->
            <div class="col-lg-5">
                <div class="bg-primary text-white rounded-4 p-4 p-md-5 h-100 d-flex flex-column justify-content-between shadow">
                    <div>
                        <h4 class="fw-bold text-white mb-4">Contact Information</h4>
                        <div class="d-flex align-items-start gap-3 mb-4">
                            <div class="p-2 bg-white bg-opacity-25 rounded-circle fs-5">
                                <i class="bi bi-geo-alt-fill"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1">Campus Location</h6>
                                <p class="mb-0 opacity-75 small">Kombe AIC Education Complex<br>P.O. Box 100, Kombe, Kenya</p>
                            </div>
                        </div>

                        <div class="d-flex align-items-start gap-3 mb-4">
                            <div class="p-2 bg-white bg-opacity-25 rounded-circle fs-5">
                                <i class="bi bi-telephone-fill"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1">Phone Contacts</h6>
                                <p class="mb-0 opacity-75 small">Primary: +254 711 000 333<br>Junior: +254 711 000 444</p>
                            </div>
                        </div>

                        <div class="d-flex align-items-start gap-3 mb-4">
                            <div class="p-2 bg-white bg-opacity-25 rounded-circle fs-5">
                                <i class="bi bi-envelope-fill"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1">Email Inquiries</h6>
                                <p class="mb-0 opacity-75 small">info@kombeschools.sc.ke<br>admissions@kombeschools.sc.ke</p>
                            </div>
                        </div>

                        <div class="d-flex align-items-start gap-3">
                            <div class="p-2 bg-white bg-opacity-25 rounded-circle fs-5">
                                <i class="bi bi-clock-fill"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1">Office Operating Hours</h6>
                                <p class="mb-0 opacity-75 small">Monday &ndash; Friday: 7:30 AM &ndash; 5:00 PM<br>Saturday: 8:00 AM &ndash; 1:00 PM</p>
                            </div>
                        </div>
                    </div>

                    <div class="pt-4 mt-4 border-top border-white border-opacity-25">
                        <small class="opacity-75">Visitors and prospective parents are warmly welcomed.</small>
                    </div>
                </div>
            </div>

            <!-- Contact Form Column -->
            <div class="col-lg-7">
                <div class="contact-box h-100">
                    <h4 class="fw-bold text-dark mb-2">Send Us an Inquiry</h4>
                    <p class="text-muted small mb-4">Fill out the form below and an administrative officer will respond within 24 hours.</p>

                    <?php if ($contact_feedback): ?>
                        <div class="alert alert-<?= $contact_feedback['type'] ?> alert-dismissible fade show" role="alert">
                            <i class="bi bi-<?= ($contact_feedback['type'] === 'success') ? 'check-circle-fill' : 'exclamation-circle-fill' ?> me-2"></i>
                            <?= e($contact_feedback['msg']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="#contact">
                        <input type="hidden" name="send_contact" value="1">
                        
                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Your Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" placeholder="e.g. Mary Wanjiku" value="<?= e($_POST['name'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Phone Number <span class="text-danger">*</span></label>
                                <input type="tel" name="phone" class="form-control" placeholder="07XXXXXXXX" value="<?= e($_POST['phone'] ?? '') ?>" required>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Email Address (Optional)</label>
                                <input type="email" name="email" class="form-control" placeholder="yourname@gmail.com" value="<?= e($_POST['email'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Division of Interest</label>
                                <select name="division_interest" class="form-select">
                                    <option value="General Inquiry">General School Inquiry</option>
                                    <option value="Kombe AIC Primary (Grades 4-6)">Kombe AIC Primary School (Grades 4-6)</option>
                                    <option value="Kombe AIC Junior (Grades 7-9)">Kombe AIC Junior School (Grades 7-9)</option>
                                    <option value="School Fees & In-Kind Contributions">School Fees & In-Kind Feeding</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label small fw-semibold text-secondary">Message / Questions <span class="text-danger">*</span></label>
                            <textarea name="message" class="form-control" rows="4" placeholder="How can we assist you?" required><?= e($_POST['message'] ?? '') ?></textarea>
                        </div>

                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary btn-lg fs-6 px-4 fw-bold shadow-sm">
                                <i class="bi bi-send-fill me-1"></i> Send Inquiry Message
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 6. PUBLIC FOOTER -->
<footer class="landing-footer">
    <div class="container">
        <div class="row g-4 pb-4 border-bottom border-secondary border-opacity-25">
            <div class="col-lg-4">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="bg-primary text-white rounded p-2">
                        <i class="bi bi-mortarboard-fill text-warning"></i>
                    </div>
                    <span class="fw-bold fs-5 text-white">KK SCHOOL MANAGEMENT SYSTEM</span>
                </div>
                <p class="small text-muted mb-3">
                    Integrated primary and junior secondary education platform serving <strong>KOMBE AIC PRIMARY SCHOOL</strong> and <strong>KOMBE AIC JUNIOR SCHOOL</strong>.
                </p>
                <div class="d-flex gap-2">
                    <a href="login.php" class="btn btn-outline-light btn-sm"><i class="bi bi-lock me-1"></i> Staff Portal</a>
                </div>
            </div>

            <div class="col-6 col-lg-2">
                <h6 class="mb-3">Quick Links</h6>
                <ul class="list-unstyled small d-flex flex-column gap-2">
                    <li><a href="#hero">Home</a></li>
                    <li><a href="#about">Who We Are</a></li>
                    <li><a href="#divisions">Our Divisions</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#contact">Contact Us</a></li>
                </ul>
            </div>

            <div class="col-6 col-lg-3">
                <h6 class="mb-3">School Divisions</h6>
                <ul class="list-unstyled small d-flex flex-column gap-2">
                    <li><a href="#divisions">Kombe AIC Primary (Gr 4-6)</a></li>
                    <li><a href="#divisions">Kombe AIC Junior (Gr 7-9)</a></li>
                    <li><a href="#services">CBC Continuous Assessments</a></li>
                    <li><a href="#services">Print-Ready Report Cards</a></li>
                    <li><a href="#services">Lunch & Food Collection</a></li>
                </ul>
            </div>

            <div class="col-lg-3">
                <h6 class="mb-3">Administration</h6>
                <p class="small text-muted mb-2">
                    Direct access for authorized educators, head teachers, directors of studies and administrators.
                </p>
                <a href="login.php" class="btn btn-warning text-dark fw-bold btn-sm w-100">
                    <i class="bi bi-box-arrow-in-right me-1"></i> Sign In to System
                </a>
            </div>
        </div>

        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-center pt-4 small">
            <div>
                &copy; <?= date('Y') ?> <?= APP_NAME ?>. All Rights Reserved.
            </div>
            <div class="text-muted mt-2 mt-sm-0">
                <?= PRIMARY_SCHOOL_NAME ?> &bull; <?= JUNIOR_SCHOOL_NAME ?>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
