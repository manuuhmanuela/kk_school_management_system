<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher']);

$pdo = get_db_connection();
$errors = [];

// Handle Collection Entry
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name       = trim($_POST['item_name'] ?? '');
    $category        = $_POST['category'] ?? 'Grain';
    $quantity        = floatval($_POST['quantity'] ?? 0);
    $unit            = trim($_POST['unit'] ?? 'kg');
    $student_id      = !empty($_POST['student_id']) ? intval($_POST['student_id']) : null;
    $contributor     = trim($_POST['contributor_name'] ?? '');
    $collection_date = !empty($_POST['collection_date']) ? $_POST['collection_date'] : date('Y-m-d');
    $notes           = trim($_POST['notes'] ?? '');

    if (empty($item_name) || $quantity <= 0) {
        $errors[] = "Item name and valid quantity are required.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO food_collections 
            (item_name, category, quantity, unit, contributed_by_student_id, contributor_name, status, collection_date, recorded_by, notes) 
            VALUES (?, ?, ?, ?, ?, ?, 'In Stock', ?, ?, ?)
        ");
        $stmt->execute([
            $item_name, $category, $quantity, $unit, 
            $student_id, $contributor, $collection_date, 
            $_SESSION['user_id'], $notes
        ]);

        log_audit('Food Stock Added', "Added {$quantity} {$unit} of {$item_name}");
        set_flash('success', "Food stock record added successfully!");
        redirect('fees/food_collection.php');
    }
}

// Fetch active stock
$collections = $pdo->query("
    SELECT fc.*, s.admission_no, s.first_name, s.last_name, u.full_name as recorder 
    FROM food_collections fc 
    LEFT JOIN students s ON fc.contributed_by_student_id = s.id 
    LEFT JOIN users u ON fc.recorded_by = u.id 
    ORDER BY fc.id DESC
")->fetchAll();

$students = $pdo->query("SELECT id, admission_no, first_name, last_name FROM students WHERE status = 'Active' ORDER BY first_name ASC")->fetchAll();

$page_title = 'Food & In-Kind Collections';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Food Collection & Stock Records</h3>
        <p class="text-muted mb-0">Track farm produce, grains and food supplies contributed towards student feeding</p>
    </div>
    <a href="<?= BASE_URL ?>fees/index.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back to School Fees
    </a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger shadow-sm">
        <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e): ?>
                <li><?= e($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Add Food Record -->
    <div class="col-lg-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold">
                <i class="bi bi-basket me-1 text-primary"></i> Receive Food / Produce Item
            </div>
            <div class="card-body p-3">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Item Description <span class="text-danger">*</span></label>
                        <input type="text" name="item_name" class="form-control" placeholder="e.g. Dry Maize, Yellow Beans, Cooking Oil" required>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Category</label>
                            <select name="category" class="form-select">
                                <option value="Grain">Grain</option>
                                <option value="Legume">Legume</option>
                                <option value="Oil">Oil</option>
                                <option value="Vegetables">Vegetables</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Quantity & Unit</label>
                            <div class="input-group">
                                <input type="number" step="0.5" name="quantity" class="form-control" placeholder="Qty" required>
                                <input type="text" name="unit" class="form-control" placeholder="kg/bags" value="bags" style="max-width: 65px;" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Contributing Learner (Optional)</label>
                        <select name="student_id" class="form-select">
                            <option value="">-- None / Direct Procurement --</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= $st['id'] ?>">
                                    <?= e($st['admission_no']) ?> &bull; <?= e($st['first_name'] . ' ' . $st['last_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Contributor Name / Parent</label>
                        <input type="text" name="contributor_name" class="form-control" placeholder="Name of parent or supplier">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Date Received</label>
                        <input type="date" name="collection_date" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold">Notes / Storage Bay</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="e.g. Stored in Main Granary Store A"></textarea>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary fw-semibold">
                            <i class="bi bi-box-arrow-in-down me-1"></i> Record Food Stock
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Stock Table -->
    <div class="col-lg-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 fw-bold d-flex justify-content-between align-items-center">
                <span><i class="bi bi-box-seam me-1 text-primary"></i> Current Food & In-Kind Inventory (<?= count($collections) ?>)</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Item & Category</th>
                                <th>Quantity In Stock</th>
                                <th>Contributed By</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($collections)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">No food collections recorded yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($collections as $c): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark"><?= e($c['item_name']) ?></div>
                                            <small class="badge bg-light text-secondary border"><?= e($c['category']) ?></small>
                                        </td>
                                        <td>
                                            <span class="fs-6 fw-bold text-primary"><?= number_format($c['quantity'], 1) ?></span> <?= e($c['unit']) ?>
                                        </td>
                                        <td>
                                            <?php if ($c['admission_no']): ?>
                                                <div class="small fw-semibold"><?= e($c['first_name'] . ' ' . $c['last_name']) ?></div>
                                                <small class="text-muted"><?= e($c['admission_no']) ?></small>
                                            <?php else: ?>
                                                <small class="text-muted"><?= e($c['contributor_name'] ?: 'Direct Purchase') ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= e($c['collection_date']) ?></td>
                                        <td>
                                            <span class="badge bg-success"><?= e($c['status']) ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
