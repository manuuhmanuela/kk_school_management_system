<?php
require_once __DIR__ . '/../config/init.php';
require_login();

$id = intval($_GET['id'] ?? 0);
$pdo = get_db_connection();

$stmt = $pdo->prepare("
    SELECT p.*, s.admission_no, s.first_name, s.middle_name, s.last_name, s.division, c.name as class_name, c.stream, u.full_name as receiver_name 
    FROM fee_payments p 
    JOIN students s ON p.student_id = s.id 
    JOIN classes c ON s.current_class_id = c.id 
    LEFT JOIN users u ON p.received_by = u.id 
    WHERE p.id = ?
");
$stmt->execute([$id]);
$payment = $stmt->fetch();

if (!$payment) {
    die("Receipt record not found.");
}

$school_name = ($payment['division'] === 'Primary') ? PRIMARY_SCHOOL_NAME : JUNIOR_SCHOOL_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?= e($payment['receipt_no']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background-color: #f8fafc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .receipt-card {
            max-width: 650px;
            margin: 40px auto;
            background: #fff;
            padding: 35px;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border: 2px dashed #0f172a;
        }
        @media print {
            body { background: #fff !important; }
            .receipt-card {
                box-shadow: none !important;
                border: 2px solid #000 !important;
                margin: 0 !important;
                max-width: 100% !important;
            }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>

<div class="container no-print text-center my-3">
    <button onclick="window.print()" class="btn btn-primary px-4 shadow-sm">
        <i class="bi bi-printer me-1"></i> Print Receipt
    </button>
    <a href="<?= BASE_URL ?>fees/index.php" class="btn btn-outline-secondary ms-2">Back to Fees</a>
</div>

<div class="receipt-card">
    <div class="text-center border-bottom pb-3 mb-3">
        <h4 class="fw-bold text-dark mb-0"><?= e($school_name) ?></h4>
        <small class="text-muted">OFFICIAL TUITION & SERVICES RECEIPT &bull; P.O. BOX 100, KOMBE</small>
        <div class="mt-2">
            <span class="badge bg-dark fs-6 px-3 py-1 font-monospace">RECEIPT NO: <?= e($payment['receipt_no']) ?></span>
        </div>
    </div>

    <div class="row g-2 mb-3 small">
        <div class="col-6">
            <span class="text-muted">Date of Payment:</span><br>
            <strong><?= date('d M Y', strtotime($payment['payment_date'])) ?></strong>
        </div>
        <div class="col-6 text-end">
            <span class="text-muted">Academic Term:</span><br>
            <strong><?= e($payment['term']) ?> &bull; <?= e($payment['academic_year']) ?></strong>
        </div>
    </div>

    <div class="border rounded p-3 mb-3 bg-light">
        <div class="row g-2 small">
            <div class="col-8">
                <span class="text-muted">Received From Learner:</span><br>
                <strong class="fs-6"><?= e($payment['first_name'] . ' ' . $payment['middle_name'] . ' ' . $payment['last_name']) ?></strong>
            </div>
            <div class="col-4 text-end">
                <span class="text-muted">Admission No:</span><br>
                <strong class="text-primary fs-6"><?= e($payment['admission_no']) ?></strong>
            </div>
            <div class="col-12 mt-1">
                <span class="text-muted">Class & Stream:</span>
                <strong><?= e($payment['division']) ?> &mdash; <?= e($payment['class_name']) ?> (<?= e($payment['stream']) ?>)</strong>
            </div>
        </div>
    </div>

    <table class="table table-bordered mb-3">
        <thead class="table-light">
            <tr>
                <th>Description</th>
                <th>Payment Mode</th>
                <th>Reference #</th>
                <th class="text-end">Amount (KES)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?= e($payment['notes'] ?: 'School Fees Contribution / Tuition') ?></td>
                <td><?= e($payment['payment_method']) ?></td>
                <td><small class="font-monospace"><?= e($payment['reference_no'] ?: 'N/A') ?></small></td>
                <td class="text-end fw-bold fs-5 text-success"><?= number_format($payment['amount_paid'], 2) ?></td>
            </tr>
            <tr class="table-light">
                <td colspan="3" class="text-end fw-bold">TOTAL PAID:</td>
                <td class="text-end fw-bold text-dark fs-5">KES <?= number_format($payment['amount_paid'], 2) ?></td>
            </tr>
        </tbody>
    </table>

    <div class="d-flex justify-content-between align-items-end mt-4 pt-3 border-top">
        <div>
            <span class="small text-muted">Received By:</span><br>
            <strong><?= e($payment['receiver_name'] ?? 'Bursar / Accounts') ?></strong>
        </div>
        <div class="text-end">
            <div style="border-bottom: 1px dotted #000; width: 180px; height: 25px;"></div>
            <small class="text-muted">Authorized Signature & Stamp</small>
        </div>
    </div>

    <div class="text-center mt-3 pt-2 text-muted" style="font-size: 0.72rem;">
        Thank you for supporting Kombe AIC Educational Excellence &bull; Fees once paid are non-refundable.
    </div>
</div>

</body>
</html>
