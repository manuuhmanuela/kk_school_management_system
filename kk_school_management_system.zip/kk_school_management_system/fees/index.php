<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher']);

$pdo = get_db_connection();
$division = get_active_division();

// Filtering
$search = trim($_GET['search'] ?? '');
$filter_division = $_GET['division_filter'] ?? (($division !== 'All') ? $division : '');

// Summary calculations
$total_collected = $pdo->query("SELECT COALESCE(SUM(amount_paid), 0) FROM fee_payments")->fetchColumn();
$total_expected  = $pdo->query("
    SELECT COALESCE(SUM(fs.amount), 0) 
    FROM students s 
    JOIN fee_structures fs ON fs.division = s.division 
    WHERE s.status = 'Active' AND fs.academic_year = '2026' AND fs.term = 'Term 1'
")->fetchColumn();
$outstanding = max(0, $total_expected - $total_collected);

// Payments list query
$query = "
    SELECT p.*, s.admission_no, s.first_name, s.last_name, s.division, c.name as class_name, u.full_name as receiver_name 
    FROM fee_payments p 
    JOIN students s ON p.student_id = s.id 
    JOIN classes c ON s.current_class_id = c.id 
    LEFT JOIN users u ON p.received_by = u.id 
    WHERE 1=1
";
$params = [];
if ($filter_division) {
    $query .= " AND s.division = ?";
    $params[] = $filter_division;
}
if ($search) {
    $query .= " AND (p.receipt_no LIKE ? OR s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)";
    $term = "%$search%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}
$query .= " ORDER BY p.id DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$payments = $stmt->fetchAll();

$page_title = 'School Fees & Balances';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">School Fees Management</h3>
        <p class="text-muted mb-0">Track student payments, print receipts, and monitor food/in-kind collections</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>fees/food_collection.php" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-box-seam me-1"></i> Food & In-Kind Stock
        </a>
        <a href="<?= BASE_URL ?>fees/pay.php" class="btn btn-primary btn-sm shadow-sm">
            <i class="bi bi-cash-coin me-1"></i> Record New Payment
        </a>
    </div>
</div>

<!-- Financial Stat Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Total Collections</span>
            <h3 class="fw-bold text-success mt-1 mb-0">KES <?= number_format($total_collected, 2) ?></h3>
            <small class="text-muted">Recorded into the system</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Term 1 Expected Inflow</span>
            <h3 class="fw-bold text-primary mt-1 mb-0">KES <?= number_format($total_expected, 2) ?></h3>
            <small class="text-muted">Based on enrolled active learners</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <span class="text-muted small fw-semibold text-uppercase">Estimated Balance Outstanding</span>
            <h3 class="fw-bold text-danger mt-1 mb-0">KES <?= number_format($outstanding, 2) ?></h3>
            <small class="text-danger">Pending collection</small>
        </div>
    </div>
</div>

<!-- Search & Filters -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-2 align-items-end">
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-secondary">Search Payment</label>
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Receipt no, Admission no, Student..." value="<?= e($search) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-semibold text-secondary">Division</label>
                <select name="division_filter" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Divisions</option>
                    <option value="Primary" <?= ($filter_division === 'Primary') ? 'selected' : '' ?>>Primary School</option>
                    <option value="Junior" <?= ($filter_division === 'Junior') ? 'selected' : '' ?>>Junior School</option>
                </select>
            </div>
            <div class="col-md-4 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm w-100">Filter Records</button>
                <a href="<?= BASE_URL ?>fees/index.php" class="btn btn-outline-secondary btn-sm">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Fee Transactions List -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold"><i class="bi bi-receipt me-2 text-primary"></i>Fee Payment Transactions (<?= count($payments) ?>)</h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Receipt #</th>
                        <th>Learner & Class</th>
                        <th>Payment Date</th>
                        <th>Term & Year</th>
                        <th>Method & Ref</th>
                        <th>Amount Paid</th>
                        <th>Received By</th>
                        <th class="text-end">Print Receipt</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">No fee transactions found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($payments as $p): ?>
                            <tr>
                                <td class="fw-bold text-primary"><?= e($p['receipt_no']) ?></td>
                                <td>
                                    <div class="fw-semibold"><?= e($p['first_name'] . ' ' . $p['last_name']) ?></div>
                                    <small class="text-muted"><?= e($p['admission_no']) ?> &bull; <?= e($p['class_name']) ?></small>
                                </td>
                                <td><?= e($p['payment_date']) ?></td>
                                <td><?= e($p['term']) ?> <?= e($p['academic_year']) ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= e($p['payment_method']) ?></span>
                                    <?php if ($p['reference_no']): ?>
                                        <div class="small text-muted font-monospace"><?= e($p['reference_no']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><strong class="text-success">KES <?= number_format($p['amount_paid'], 2) ?></strong></td>
                                <td class="small text-muted"><?= e($p['receiver_name'] ?? 'Admin') ?></td>
                                <td class="text-end">
                                    <a href="<?= BASE_URL ?>fees/receipt.php?id=<?= $p['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary shadow-sm" title="Print Official Receipt">
                                        <i class="bi bi-printer"></i> Receipt
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
