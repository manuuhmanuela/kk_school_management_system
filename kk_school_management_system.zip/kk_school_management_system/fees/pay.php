<?php
require_once __DIR__ . '/../config/init.php';
require_roles(['Owner', 'Administrator', 'Head Teacher']);

$pdo = get_db_connection();
$errors = [];

// Handle Fee Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id     = intval($_POST['student_id'] ?? 0);
    $amount_paid    = floatval($_POST['amount_paid'] ?? 0);
    $payment_method = $_POST['payment_method'] ?? 'Cash';
    $reference_no   = trim($_POST['reference_no'] ?? '');
    $payment_date   = !empty($_POST['payment_date']) ? $_POST['payment_date'] : date('Y-m-d');
    $term           = $_POST['term'] ?? 'Term 1';
    $academic_year  = trim($_POST['academic_year'] ?? '2026');
    $notes          = trim($_POST['notes'] ?? '');

    if (!$student_id) $errors[] = "Please select a student.";
    if ($amount_paid <= 0) $errors[] = "Please specify a valid payment amount.";

    if (empty($errors)) {
        // Auto-generate unique receipt number
        $receipt_no = 'REC-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));

        $stmt = $pdo->prepare("
            INSERT INTO fee_payments 
            (receipt_no, student_id, amount_paid, payment_method, reference_no, payment_date, term, academic_year, received_by, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $receipt_no, $student_id, $amount_paid, $payment_method, 
            $reference_no, $payment_date, $term, $academic_year, 
            $_SESSION['user_id'], $notes
        ]);

        $payment_id = $pdo->lastInsertId();
        log_audit('Fee Payment Recorded', "Recorded receipt {$receipt_no} for student ID {$student_id} (KES {$amount_paid})");
        set_flash('success', "Payment successfully recorded! Receipt #: {$receipt_no}");

        // Redirect directly to receipt print page
        redirect("fees/receipt.php?id={$payment_id}");
    }
}

// Fetch students for selection
$students = $pdo->query("SELECT s.id, s.admission_no, s.first_name, s.last_name, s.division, c.name as class_name FROM students s JOIN classes c ON s.current_class_id = c.id WHERE s.status = 'Active' ORDER BY s.division ASC, c.id ASC, s.first_name ASC")->fetchAll();

$page_title = 'Record Fee Payment';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Record Fee Payment</h3>
                <p class="text-muted mb-0">Issue payment receipt for tuition, lunch or development fund</p>
            </div>
            <a href="<?= BASE_URL ?>fees/index.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Back to Fees
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger shadow-sm">
                <ul class="mb-0 ps-3">
                    <?php foreach ($errors as $e): ?>
                        <li><?= e($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Learner <span class="text-danger">*</span></label>
                        <select name="student_id" class="form-select" required>
                            <option value="">-- Choose Learner --</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= $st['id'] ?>" <?= (($_GET['student_id'] ?? '') == $st['id']) ? 'selected' : '' ?>>
                                    [<?= e($st['division']) ?>] <?= e($st['admission_no']) ?> &mdash; <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['class_name']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Amount Paid (KES) <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">KES</span>
                                <input type="number" step="100" min="1" name="amount_paid" class="form-control" placeholder="e.g. 5000" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Payment Date <span class="text-danger">*</span></label>
                            <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Payment Method</label>
                            <select name="payment_method" class="form-select">
                                <option value="Cash">Cash</option>
                                <option value="M-Pesa">M-Pesa</option>
                                <option value="Bank Deposit">Bank Deposit / Slip</option>
                                <option value="Cheque">Cheque</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Reference / Transaction Code</label>
                            <input type="text" name="reference_no" class="form-control" placeholder="e.g. M-Pesa Code / Slip No">
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Academic Term</label>
                            <select name="term" class="form-select">
                                <option value="Term 1">Term 1</option>
                                <option value="Term 2">Term 2</option>
                                <option value="Term 3">Term 3</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Academic Year</label>
                            <input type="text" name="academic_year" class="form-control" value="2026" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Payment Notes / Description</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="e.g. Balance clearance for Term 1 tuition"></textarea>
                    </div>

                    <div class="d-flex justify-content-end gap-2 border-top pt-3">
                        <a href="<?= BASE_URL ?>fees/index.php" class="btn btn-light border">Cancel</a>
                        <button type="submit" class="btn btn-success fw-semibold px-4">
                            <i class="bi bi-printer me-1"></i> Save & Generate Receipt
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
